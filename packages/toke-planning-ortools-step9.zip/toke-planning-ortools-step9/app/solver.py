from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from math import floor

from ortools.sat.python import cp_model

from app.schemas import (
    AllocationMode,
    CoverageResult,
    DayReason,
    EngineDiagnostics,
    EngineResult,
    EngineTemplate,
    EmployeeSuggestionResult,
    PlanningRequirementInput,
    PlanningSolverInput,
    PlanningViolation,
    SolverResponse,
)


DAY_KEYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


@dataclass(frozen=True)
class RequirementSlot:
    requirement: PlanningRequirementInput
    iso: str


def parse_iso(value: str) -> date:
    return datetime.strptime(value, "%Y-%m-%d").date()


def add_days(value: str, amount: int) -> str:
    return (parse_iso(value) + timedelta(days=amount)).isoformat()


def period_dates(start: str, end: str) -> list[str]:
    current = parse_iso(start)
    last = parse_iso(end)
    if current > last:
        raise ValueError("periodFrom must be <= periodTo")

    result: list[str] = []
    while current <= last:
        result.append(current.isoformat())
        current += timedelta(days=1)
    return result


def day_key(iso: str) -> str:
    return DAY_KEYS[parse_iso(iso).weekday()]


def is_weekend(iso: str) -> bool:
    return day_key(iso) in {"Sat", "Sun"}


def monday_of_week(iso: str) -> str:
    value = parse_iso(iso)
    return (value - timedelta(days=value.weekday())).isoformat()


def to_minutes(value: str) -> int:
    hours, minutes = value.split(":")
    return int(hours) * 60 + int(minutes)


def blocks_for(template: EngineTemplate, iso: str):
    return template.definition.get(day_key(iso)) or []


def template_has_work(template: EngineTemplate, iso: str) -> bool:
    return bool(blocks_for(template, iso))


def template_minutes(template: EngineTemplate, iso: str) -> int:
    total = 0
    for block in blocks_for(template, iso):
        start = to_minutes(block.work[0])
        end = to_minutes(block.work[1])
        if end <= start:
            end += 24 * 60
        duration = end - start

        if block.pause:
            pause_start = to_minutes(block.pause[0])
            pause_end = to_minutes(block.pause[1])
            if pause_end <= pause_start:
                pause_end += 24 * 60
            duration -= pause_end - pause_start

        total += max(0, duration)

    return total


def first_start(template: EngineTemplate, iso: str) -> int | None:
    blocks = blocks_for(template, iso)
    if not blocks:
        return None
    return min(to_minutes(block.work[0]) for block in blocks)


def last_end(template: EngineTemplate, iso: str) -> int | None:
    blocks = blocks_for(template, iso)
    if not blocks:
        return None

    values: list[int] = []
    for block in blocks:
        start = to_minutes(block.work[0])
        end = to_minutes(block.work[1])
        if end <= start:
            end += 24 * 60
        values.append(end)
    return max(values)


class OrToolsPlanner:
    def __init__(self, request: PlanningSolverInput):
        self.request = request
        self.model = cp_model.CpModel()
        self.solver = cp_model.CpSolver()

        self.dates = period_dates(request.periodFrom, request.periodTo)
        self.rotating = [
            employee
            for employee in request.employees
            if employee.mode == "ROTATING"
        ]
        self.fixed = [
            employee
            for employee in request.employees
            if employee.mode == "FIXED"
        ]

        self.slots: list[RequirementSlot] = []
        for iso in self.dates:
            current_day = day_key(iso)
            for requirement in request.requirements:
                if requirement.dayOfWeek == current_day:
                    self.slots.append(RequirementSlot(requirement, iso))

        # x[(employee_guid, date, requirement_guid)] = selected requirement.
        self.x: dict[tuple[str, str, str], cp_model.IntVar] = {}

        # Work activity includes a normal assignment or guard continuation.
        self.work_day: dict[tuple[str, str], cp_model.IntVar] = {}
        self.guard_day: dict[tuple[str, str], cp_model.IntVar] = {}

        self.fixed_counts: dict[tuple[str, str], int] = defaultdict(int)
        self.history_shift_count: dict[str, int] = defaultdict(int)
        self.history_guard_count: dict[str, int] = defaultdict(int)
        self.history_weekend_count: dict[str, int] = defaultdict(int)
        self.history_minutes: dict[str, int] = defaultdict(int)
        self.history_template_count: dict[tuple[str, str], int] = defaultdict(int)

        self.under_target_vars: list[cp_model.IntVar] = []
        self.fill_vars: list[cp_model.IntVar] = []
        self.objective_terms: list = []

    def build(self) -> None:
        self._validate_templates()
        self._build_history()
        self._build_fixed_counts()
        self._build_variables()
        self._apply_one_assignment_per_day()
        self._apply_guard_continuations()
        self._build_work_days()
        self._apply_coverage()
        self._apply_weekly_rest()
        self._apply_max_consecutive_work_days()
        self._apply_weekly_minutes()
        self._apply_max_consecutive_guards()
        self._apply_rest_between_shifts()
        self._build_objective()

    def _validate_templates(self) -> None:
        violations = []
        for slot in self.slots:
            requirement = slot.requirement
            if not template_has_work(requirement.template, slot.iso):
                violations.append(
                    f"{requirement.template.name} has no work block on {slot.iso}"
                )

            if requirement.serviceType == "GUARD":
                continuation_date = add_days(
                    slot.iso, requirement.continuationDayOffset
                )
                if not requirement.continuationTemplate or not template_has_work(
                    requirement.continuationTemplate, continuation_date
                ):
                    violations.append(
                        f"{requirement.template.name} has no valid continuation on "
                        f"{continuation_date}"
                    )

        for employee in self.fixed:
            assert employee.fixedTemplate is not None
            for iso in self.dates:
                # A fixed template is allowed to define rest on some dates.
                _ = employee.fixedTemplate.definition.get(day_key(iso))

        if violations:
            raise ValueError("; ".join(violations))

    def _build_history(self) -> None:
        employee_guids = {employee.guid for employee in self.rotating}

        for assignment in self.request.historicalAssignments:
            if assignment.userGuid not in employee_guids:
                continue

            current = max(parse_iso(assignment.startDate), parse_iso(
                add_days(
                    self.request.periodFrom,
                    -(self.request.config.fairnessWindowWeeks * 7),
                )
            ))
            end = min(
                parse_iso(assignment.endDate),
                parse_iso(add_days(self.request.periodFrom, -1)),
            )

            template = EngineTemplate(
                guid=assignment.templateGuid,
                name=assignment.templateName,
                definition=assignment.definition,
            )

            while current <= end:
                iso = current.isoformat()
                if template_has_work(template, iso):
                    minutes = template_minutes(template, iso)
                    self.history_shift_count[assignment.userGuid] += 1
                    self.history_minutes[assignment.userGuid] += minutes
                    self.history_template_count[
                        (assignment.userGuid, assignment.templateGuid)
                    ] += 1
                    if assignment.serviceType == "GUARD":
                        self.history_guard_count[assignment.userGuid] += 1
                    if is_weekend(iso):
                        self.history_weekend_count[assignment.userGuid] += 1
                current += timedelta(days=1)

    def _build_fixed_counts(self) -> None:
        for employee in self.fixed:
            assert employee.fixedTemplate is not None
            for iso in self.dates:
                if template_has_work(employee.fixedTemplate, iso):
                    self.fixed_counts[(iso, employee.fixedTemplate.guid)] += 1

    def _build_variables(self) -> None:
        for employee in self.rotating:
            for slot in self.slots:
                key = (employee.guid, slot.iso, slot.requirement.guid)
                self.x[key] = self.model.NewBoolVar(
                    f"x_{employee.guid}_{slot.iso}_{slot.requirement.guid}"
                )

    def _slot_var(self, employee_guid: str, slot: RequirementSlot):
        return self.x[(employee_guid, slot.iso, slot.requirement.guid)]

    def _daily_slots(self, iso: str) -> list[RequirementSlot]:
        return [slot for slot in self.slots if slot.iso == iso]

    def _guard_slots(self, iso: str) -> list[RequirementSlot]:
        return [
            slot
            for slot in self._daily_slots(iso)
            if slot.requirement.serviceType == "GUARD"
        ]

    def _apply_one_assignment_per_day(self) -> None:
        for employee in self.rotating:
            for iso in self.dates:
                variables = [
                    self._slot_var(employee.guid, slot)
                    for slot in self._daily_slots(iso)
                ]
                if variables:
                    self.model.Add(sum(variables) <= 1)

    def _apply_guard_continuations(self) -> None:
        # A continuation is worked from 00:00/00:01 to 08:00 and therefore
        # always blocks another ordinary assignment on the same calendar day.
        for employee in self.rotating:
            for slot in self.slots:
                if slot.requirement.serviceType != "GUARD":
                    continue

                guard_var = self._slot_var(employee.guid, slot)
                continuation_date = add_days(
                    slot.iso, slot.requirement.continuationDayOffset
                )

                if continuation_date not in self.dates:
                    continue

                next_day_variables = [
                    self._slot_var(employee.guid, next_slot)
                    for next_slot in self._daily_slots(continuation_date)
                ]

                if next_day_variables:
                    self.model.Add(sum(next_day_variables) == 0).OnlyEnforceIf(
                        guard_var
                    )

    def _build_work_days(self) -> None:
        for employee in self.rotating:
            for iso in self.dates:
                current_assignments = [
                    self._slot_var(employee.guid, slot)
                    for slot in self._daily_slots(iso)
                ]

                previous_guard_vars = []
                previous_date = add_days(iso, -1)
                for slot in self._guard_slots(previous_date):
                    if slot.requirement.continuationDayOffset == 1:
                        previous_guard_vars.append(
                            self._slot_var(employee.guid, slot)
                        )

                active_terms = current_assignments + previous_guard_vars
                variable = self.model.NewBoolVar(
                    f"work_day_{employee.guid}_{iso}"
                )
                self.work_day[(employee.guid, iso)] = variable

                if not active_terms:
                    self.model.Add(variable == 0)
                else:
                    self.model.Add(variable == sum(active_terms))

                guard_terms = [
                    self._slot_var(employee.guid, slot)
                    for slot in self._guard_slots(iso)
                ]
                guard_variable = self.model.NewBoolVar(
                    f"guard_day_{employee.guid}_{iso}"
                )
                self.guard_day[(employee.guid, iso)] = guard_variable
                if guard_terms:
                    self.model.Add(guard_variable == sum(guard_terms))
                else:
                    self.model.Add(guard_variable == 0)

    def _apply_coverage(self) -> None:
        for slot in self.slots:
            requirement = slot.requirement
            variables = [
                self._slot_var(employee.guid, slot)
                for employee in self.rotating
            ]
            fixed_count = self.fixed_counts[
                (slot.iso, requirement.template.guid)
            ]
            total = sum(variables) + fixed_count

            if requirement.allocationMode == "EXACT":
                self.model.Add(total == requirement.targetEmployees)
                continue

            self.model.Add(total >= requirement.minEmployees)
            if requirement.maxEmployees is not None:
                self.model.Add(total <= requirement.maxEmployees)

            if requirement.allocationMode == "RANGE":
                under_target = self.model.NewIntVar(
                    0,
                    max(0, requirement.targetEmployees),
                    f"under_target_{slot.iso}_{requirement.guid}",
                )
                self.model.Add(
                    under_target
                    >= requirement.targetEmployees - total
                )
                self.under_target_vars.append(under_target)

            if requirement.allocationMode == "FILL_REMAINING":
                self.fill_vars.extend(variables)

    def _week_groups(self) -> dict[str, list[str]]:
        result: dict[str, list[str]] = defaultdict(list)
        for iso in self.dates:
            result[monday_of_week(iso)].append(iso)
        return result

    def _apply_weekly_rest(self) -> None:
        for employee in self.rotating:
            for _, dates in self._week_groups().items():
                allowed_work_days = max(
                    0,
                    len(dates) - self.request.config.minRestDaysPerWeek,
                )
                self.model.Add(
                    sum(
                        self.work_day[(employee.guid, iso)]
                        for iso in dates
                    )
                    <= allowed_work_days
                )

    def _apply_max_consecutive_work_days(self) -> None:
        size = self.request.config.maxConsecutiveWorkDays + 1
        if size > len(self.dates):
            return

        for employee in self.rotating:
            for index in range(0, len(self.dates) - size + 1):
                window = self.dates[index : index + size]
                self.model.Add(
                    sum(
                        self.work_day[(employee.guid, iso)]
                        for iso in window
                    )
                    <= self.request.config.maxConsecutiveWorkDays
                )

    def _minutes_for_slot(self, slot: RequirementSlot) -> int:
        total = template_minutes(slot.requirement.template, slot.iso)
        if (
            slot.requirement.serviceType == "GUARD"
            and slot.requirement.continuationTemplate is not None
        ):
            continuation_date = add_days(
                slot.iso, slot.requirement.continuationDayOffset
            )
            total += template_minutes(
                slot.requirement.continuationTemplate,
                continuation_date,
            )
        return total

    def _slot_minutes_in_dates(
        self,
        slot: RequirementSlot,
        date_set: set[str],
    ) -> int:
        total = 0

        if slot.iso in date_set:
            total += template_minutes(
                slot.requirement.template,
                slot.iso,
            )

        if (
            slot.requirement.serviceType == "GUARD"
            and slot.requirement.continuationTemplate is not None
        ):
            continuation_date = add_days(
                slot.iso,
                slot.requirement.continuationDayOffset,
            )
            if continuation_date in date_set:
                total += template_minutes(
                    slot.requirement.continuationTemplate,
                    continuation_date,
                )

        return total

    def _apply_weekly_minutes(self) -> None:
        for employee in self.rotating:
            maximum = (
                employee.maxWeeklyMinutes
                if employee.maxWeeklyMinutes is not None
                else self.request.config.maxWeeklyMinutes
            )
            if maximum is None:
                continue

            for _, dates in self._week_groups().items():
                date_set = set(dates)
                terms = []

                for slot in self.slots:
                    minutes = self._slot_minutes_in_dates(
                        slot,
                        date_set,
                    )
                    if minutes <= 0:
                        continue

                    terms.append(
                        minutes
                        * self._slot_var(employee.guid, slot)
                    )

                if terms:
                    self.model.Add(
                        sum(terms) <= maximum
                    )

    def _apply_max_consecutive_guards(self) -> None:
        size = self.request.config.maxConsecutiveGuards + 1
        if size > len(self.dates):
            return

        for employee in self.rotating:
            for index in range(0, len(self.dates) - size + 1):
                window = self.dates[index : index + size]
                self.model.Add(
                    sum(
                        self.guard_day[(employee.guid, iso)]
                        for iso in window
                    )
                    <= self.request.config.maxConsecutiveGuards
                )

    def _apply_rest_between_shifts(self) -> None:
        minimum = self.request.config.minRestMinutesBetweenShifts
        if minimum <= 0:
            return

        for employee in self.rotating:
            for index in range(len(self.dates) - 1):
                current_date = self.dates[index]
                next_date = self.dates[index + 1]

                for first_slot in self._daily_slots(current_date):
                    first_end = last_end(
                        first_slot.requirement.template, current_date
                    )
                    if first_end is None:
                        continue

                    # Guard continuation is handled separately and blocks next day.
                    if first_slot.requirement.serviceType == "GUARD":
                        continue

                    for second_slot in self._daily_slots(next_date):
                        second_start = first_start(
                            second_slot.requirement.template, next_date
                        )
                        if second_start is None:
                            continue

                        gap = (24 * 60 - first_end) + second_start
                        if gap < minimum:
                            self.model.Add(
                                self._slot_var(employee.guid, first_slot)
                                + self._slot_var(employee.guid, second_slot)
                                <= 1
                            )

    def _build_objective(self) -> None:
        # Hard coverage is already constrained. RANGE shortfalls remain costly.
        objective = []
        objective.extend(10_000 * variable for variable in self.under_target_vars)

        # FILL_REMAINING should use every employee still compatible with rest rules.
        objective.extend(-1_000 * variable for variable in self.fill_vars)

        if self.rotating:
            maximum_historical_shifts = max(
                (
                    self.history_shift_count[
                        employee.guid
                    ]
                    for employee in self.rotating
                ),
                default=0,
            )
            maximum_historical_guards = max(
                (
                    self.history_guard_count[
                        employee.guid
                    ]
                    for employee in self.rotating
                ),
                default=0,
            )

            max_shifts = self.model.NewIntVar(
                0,
                len(self.dates)
                + maximum_historical_shifts,
                "max_planned_shifts",
            )
            min_shifts = self.model.NewIntVar(
                0,
                len(self.dates)
                + maximum_historical_shifts,
                "min_planned_shifts",
            )
            max_guards = self.model.NewIntVar(
                0,
                len(self.dates)
                + maximum_historical_guards,
                "max_planned_guards",
            )
            min_guards = self.model.NewIntVar(
                0,
                len(self.dates)
                + maximum_historical_guards,
                "min_planned_guards",
            )

            for employee in self.rotating:
                shifts = sum(
                    self.work_day[(employee.guid, iso)]
                    for iso in self.dates
                )
                guards = sum(
                    self.guard_day[(employee.guid, iso)]
                    for iso in self.dates
                )

                # Include historical loads so a heavily used employee is penalized.
                historical_shifts = self.history_shift_count[employee.guid]
                historical_guards = self.history_guard_count[employee.guid]

                self.model.Add(shifts + historical_shifts <= max_shifts)
                self.model.Add(shifts + historical_shifts >= min_shifts)
                self.model.Add(guards + historical_guards <= max_guards)
                self.model.Add(guards + historical_guards >= min_guards)

                for slot in self.slots:
                    history_cost = self.history_template_count[
                        (employee.guid, slot.requirement.template.guid)
                    ]
                    if history_cost:
                        objective.append(
                            history_cost
                            * 5
                            * self._slot_var(employee.guid, slot)
                        )

            objective.append(100 * (max_guards - min_guards))
            objective.append(10 * (max_shifts - min_shifts))

        self.model.Minimize(sum(objective) if objective else 0)

    def solve(self) -> SolverResponse:
        self.build()

        self.solver.parameters.max_time_in_seconds = 20.0
        self.solver.parameters.num_search_workers = 8
        self.solver.parameters.random_seed = 42

        status = self.solver.Solve(self.model)
        status_name = self.solver.StatusName(status)

        if status == cp_model.INFEASIBLE:
            diagnostics = EngineDiagnostics(
                violations=[
                    PlanningViolation(
                        severity="HARD",
                        code="PLANNING_INFEASIBLE",
                        message="CP-SAT proved that no planning satisfies all hard constraints",
                    )
                ],
                coverage=[],
                fairnessScore=0,
                coverageScore=0,
            )
            return SolverResponse(
                success=False,
                status="INFEASIBLE",
                diagnostics=diagnostics,
                message="No feasible planning satisfies every hard constraint",
            )

        if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            return SolverResponse(
                success=False,
                status="UNKNOWN",
                message=f"CP-SAT stopped with status {status_name}",
            )

        result = self._build_result()
        return SolverResponse(
            success=True,
            status="OPTIMAL" if status == cp_model.OPTIMAL else "FEASIBLE",
            result=result,
        )

    def _build_result(self) -> EngineResult:
        schedules: dict[str, dict[str, str | None]] = {}
        reasons: dict[str, dict[str, DayReason | None]] = {}

        for employee in self.request.employees:
            schedules[employee.guid] = {}
            reasons[employee.guid] = {}

        # Fixed profiles are authoritative.
        for employee in self.fixed:
            assert employee.fixedTemplate is not None
            for iso in self.dates:
                if template_has_work(employee.fixedTemplate, iso):
                    schedules[employee.guid][iso] = employee.fixedTemplate.guid
                    reasons[employee.guid][iso] = DayReason(
                        templateName=employee.fixedTemplate.name,
                        templateGuid=employee.fixedTemplate.guid,
                        confidence=100,
                        source="FIXED",
                        factors=[
                            "Planning fixe défini dans le profil de l’employé"
                        ],
                    )
                else:
                    schedules[employee.guid][iso] = None
                    reasons[employee.guid][iso] = DayReason(
                        templateName="Repos",
                        templateGuid=None,
                        confidence=100,
                        source="FIXED",
                        factors=["Repos défini par le template fixe"],
                    )

        for employee in self.rotating:
            for iso in self.dates:
                selected = None
                for slot in self._daily_slots(iso):
                    if self.solver.Value(self._slot_var(employee.guid, slot)):
                        selected = slot
                        break

                if selected is None:
                    schedules[employee.guid][iso] = None
                    reasons[employee.guid][iso] = DayReason(
                        templateName="Repos",
                        templateGuid=None,
                        confidence=100,
                        source="REST",
                        factors=[
                            "Repos retenu par CP-SAT pour satisfaire les contraintes globales"
                        ],
                    )
                    continue

                requirement = selected.requirement
                source = (
                    "FILL_REMAINING"
                    if requirement.allocationMode == "FILL_REMAINING"
                    else "GENERATED"
                )
                schedules[employee.guid][iso] = requirement.template.guid
                reasons[employee.guid][iso] = DayReason(
                    templateName=requirement.template.name,
                    templateGuid=requirement.template.guid,
                    confidence=100,
                    source=source,
                    factors=[
                        f"Solution globale CP-SAT — mode {requirement.allocationMode}",
                        "Toutes les contraintes obligatoires ont été vérifiées simultanément",
                    ],
                )

                if (
                    requirement.serviceType == "GUARD"
                    and requirement.continuationTemplate is not None
                ):
                    continuation_date = add_days(
                        iso, requirement.continuationDayOffset
                    )
                    schedules[employee.guid][
                        continuation_date
                    ] = requirement.continuationTemplate.guid
                    reasons[employee.guid][
                        continuation_date
                    ] = DayReason(
                        templateName=requirement.continuationTemplate.name,
                        templateGuid=requirement.continuationTemplate.guid,
                        confidence=100,
                        source="GUARD_CONTINUATION",
                        factors=[
                            f"Suite automatique de la garde commencée le {iso}",
                            "Aucun autre service autorisé pendant cette journée de récupération",
                        ],
                    )

        coverage: list[CoverageResult] = []
        violations: list[PlanningViolation] = []

        for slot in self.slots:
            requirement = slot.requirement
            assigned = self.fixed_counts[
                (slot.iso, requirement.template.guid)
            ] + sum(
                self.solver.Value(self._slot_var(employee.guid, slot))
                for employee in self.rotating
            )

            status = "COVERED"
            if assigned < requirement.minEmployees:
                status = "BELOW_MINIMUM"
            elif assigned < requirement.targetEmployees:
                status = "BELOW_TARGET"
            elif (
                requirement.maxEmployees is not None
                and assigned > requirement.maxEmployees
            ):
                status = "ABOVE_MAXIMUM"

            coverage.append(
                CoverageResult(
                    date=slot.iso,
                    dayOfWeek=day_key(slot.iso),
                    requirementGuid=requirement.guid,
                    allocationMode=requirement.allocationMode,
                    templateGuid=requirement.template.guid,
                    templateName=requirement.template.name,
                    minimum=requirement.minEmployees,
                    target=requirement.targetEmployees,
                    maximum=requirement.maxEmployees,
                    assigned=assigned,
                    status=status,
                )
            )

        coverage_score = self._coverage_score(coverage)
        fairness_score = self._fairness_score()
        conformity = round(coverage_score * 0.75 + fairness_score * 0.25)

        diagnostics = EngineDiagnostics(
            violations=violations,
            coverage=coverage,
            fairnessScore=fairness_score,
            coverageScore=coverage_score,
        )

        return EngineResult(
            items=[
                EmployeeSuggestionResult(
                    userGuid=employee.guid,
                    schedule=schedules[employee.guid],
                    reasons=reasons[employee.guid],
                )
                for employee in self.request.employees
                if employee.mode != "EXCLUDED"
            ],
            conformityScore=conformity,
            diagnostics=diagnostics,
        )

    @staticmethod
    def _coverage_score(coverage: list[CoverageResult]) -> int:
        if not coverage:
            return 0
        total = 0.0
        for slot in coverage:
            if slot.target == 0:
                total += 1.0
            else:
                total += min(1.0, slot.assigned / slot.target)
        return round((total / len(coverage)) * 100)

    def _fairness_score(self) -> int:
        if len(self.rotating) <= 1:
            return 100

        loads = []
        for employee in self.rotating:
            shifts = sum(
                self.solver.Value(self.work_day[(employee.guid, iso)])
                for iso in self.dates
            )
            guards = sum(
                self.solver.Value(self.guard_day[(employee.guid, iso)])
                for iso in self.dates
            )
            weekends = sum(
                self.solver.Value(self.work_day[(employee.guid, iso)])
                for iso in self.dates
                if is_weekend(iso)
            )
            loads.append(shifts + guards * 2 + weekends)

        spread = max(loads) - min(loads)
        return max(0, round(100 - spread * 12.5))


def solve_planning(request: PlanningSolverInput) -> SolverResponse:
    return OrToolsPlanner(request).solve()
