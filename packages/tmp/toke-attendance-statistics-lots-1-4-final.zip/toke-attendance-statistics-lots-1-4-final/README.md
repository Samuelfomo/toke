# Module tenant de statistiques de pointage — paquet cumulatif final lots 1 à 4

## Contenu

Ce paquet réunit en un seul livrable :

- **Lot 1** — source de vérité journalière `AttendanceDay` ;
- **Lot 2** — agrégation fiable `AttendanceOverview` ;
- **Lot 3** — contrat API, exemple de réponse et contrôles de cohérence ;
- **Lot 4** — périmètre de l’équipe actuelle, orchestration tenant, validation des dates, contrôleur, route, tests et guide d’intégration.

## Endpoint livré

```http
GET /attendance/statistics/overview
```

Paramètres :

```text
manager=<guid>                         obligatoire
site=<guid>                            optionnel
start_date=YYYY-MM-DD                  optionnel avec end_date
end_date=YYYY-MM-DD                    optionnel avec start_date
```

## Décisions conservées

- Le périmètre correspond aux membres **actuels** de l’équipe du manager.
- Les sous-équipes ne sont pas ajoutées implicitement.
- `ABSENT` n’existe que pour une journée de travail valide et terminée.
- `PENDING`, `REST_DAY` et `UNDETERMINED` sont exclus du taux.
- Une présence sur repos reste `REST_DAY` et produit `PRESENCE_ON_REST_DAY`.
- Une présence sans planning reste `UNDETERMINED` et produit `PRESENCE_WITHOUT_SCHEDULE`.
- Les heures fournies par le serveur ne sont pas reconverties pour l’affichage.
- Les calculs de référence sont centralisés dans le domaine et l’application, pas dans la route.

## Arborescence

```text
src/tenant/modules/attendance-statistics/
├── application/
│   ├── attendance-overview.test.ts
│   ├── attendance-overview.ts
│   ├── attendance-overview.types.ts
│   ├── attendance-statistics.ports.ts
│   ├── attendance-statistics.service.test.ts
│   └── attendance-statistics.service.ts
├── docs/
│   └── attendance-overview.contract.md
├── domain/
│   ├── attendance-day.test.ts
│   ├── attendance-day.ts
│   └── attendance-day.types.ts
├── examples/
│   └── attendance-overview.response.json
├── http/
│   ├── attendance-statistics.controller.ts
│   ├── attendance-statistics.query.test.ts
│   └── attendance-statistics.query.ts
├── infrastructure/
│   ├── postgres-interval.test.ts
│   ├── postgres-interval.ts
│   └── tenant-attendance-statistics.adapter.ts
└── index.ts

src/tenant/routes/
└── attendance.statistics.route.ts

integration/
├── APP_INTEGRATION_SNIPPET.ts
├── TENANT_INTEGRATION_GUIDE.md
├── VALIDATION_CHECKLIST.md
├── app.ts.patch
└── attendance-statistics.smoke.http
```

## Manifeste

Lire `LOT_MANIFEST.md` pour le détail des responsabilités de chaque lot.

## Vérification du noyau pur

```bash
tsc -p tsconfig.core.json
npm run test:core
```

## Intégration

Lire en priorité :

```text
integration/TENANT_INTEGRATION_GUIDE.md
```

Le module est prévu pour coexister avec l’ancienne route pendant la recette. Ne supprimer l’ancien endpoint qu’après validation sur des données réelles.
