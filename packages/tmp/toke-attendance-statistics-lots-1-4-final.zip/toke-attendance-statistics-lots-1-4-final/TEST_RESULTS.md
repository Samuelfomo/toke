# Résultats de validation du paquet

Date : 5 août 2026

## Noyau TypeScript strict

Commande exécutée :

```bash
npm run test:core
```

Résultat :

```text
Suites : 6
Tests  : 39
Succès : 39
Échecs : 0
```

Couverture fonctionnelle des tests :

- classification `PRESENT`, `LATE`, `ABSENT`, `PENDING`, `REST_DAY`, `UNDETERMINED` ;
- tolérance de retard ;
- présence sur repos et sans planning ;
- sessions ouvertes, incomplètes et durées manquantes ;
- calcul des taux et des durées ;
- périmètre fourni par l’équipe actuelle ;
- manager et site inconnus ;
- journées et blocs traversant minuit ;
- validation stricte des dates ;
- période maximale de 366 jours ;
- paramètres de requête répétés ;
- lecture des formats usuels d’`INTERVAL` PostgreSQL.

## Contrat d’intégration

Le module complet, y compris l’adaptateur tenant, le contrôleur et la route, a été compilé en TypeScript strict dans un environnement de contrôle avec des contrats simulant les classes existantes.

Résultat : aucune erreur TypeScript.

## Limite de validation

Aucune base tenant réelle n’était connectée pendant la génération du paquet. La validation fonctionnelle finale des données, plannings, sessions de garde et filtres site reste à exécuter après intégration dans le projet principal.
