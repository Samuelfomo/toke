#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

required=(
  "src/tenant/modules/attendance-statistics/domain/attendance-day.ts"
  "src/tenant/modules/attendance-statistics/application/attendance-overview.ts"
  "src/tenant/modules/attendance-statistics/application/attendance-statistics.service.ts"
  "src/tenant/modules/attendance-statistics/http/attendance-statistics.controller.ts"
  "src/tenant/modules/attendance-statistics/infrastructure/tenant-attendance-statistics.adapter.ts"
  "src/tenant/routes/attendance.statistics.route.ts"
  "integration/TENANT_INTEGRATION_GUIDE.md"
)

for file in "${required[@]}"; do
  [[ -f "$file" ]] || { echo "Fichier manquant: $file" >&2; exit 1; }
done

npm run test:core

echo "Paquet vérifié avec succès."
