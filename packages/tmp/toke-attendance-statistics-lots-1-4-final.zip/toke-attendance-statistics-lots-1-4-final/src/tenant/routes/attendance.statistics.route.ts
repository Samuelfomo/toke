import { Router } from 'express';

import Ensure from '../../middle/ensured-routes.js';
import { createAttendanceStatisticsController } from '../modules/attendance-statistics/http/attendance-statistics.controller.js';

const router = Router();
const controller = createAttendanceStatisticsController();

/**
 * GET /attendance/statistics/overview
 *
 * Query :
 * - manager      : GUID obligatoire
 * - site         : GUID optionnel
 * - start_date   : YYYY-MM-DD, optionnel avec end_date
 * - end_date     : YYYY-MM-DD, optionnel avec start_date
 */
router.get('/overview', Ensure.get(), controller.overview);

export default router;
