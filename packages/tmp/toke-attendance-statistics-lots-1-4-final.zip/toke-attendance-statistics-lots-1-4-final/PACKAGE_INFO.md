# Informations du paquet

- Nom : `toke-attendance-statistics-lots-1-4-final`
- Date de génération : 2026-08-05
- Cible : API tenant Express + TypeScript + Sequelize + PostgreSQL
- Endpoint : `GET /attendance/statistics/overview`
- Nouvelle dépendance npm : aucune
- Périmètre organisationnel : équipe actuelle directe du manager
- Période maximale : 366 jours
- Tests purs : 39/39 réussis
- Contrôle TypeScript du contrat d’intégration : réussi
- Statut : paquet d’intégration à valider sur données tenant réelles
