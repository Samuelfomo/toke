# Checklist de validation

- [ ] Les fichiers du module sont copiés sans modifier les anciens endpoints.
- [ ] La route est montée sur `/attendance/statistics`.
- [ ] `GET /attendance/statistics/overview` répond avec authentification et tenant actifs.
- [ ] Le manager ne voit que son équipe actuelle.
- [ ] Les sous-équipes ne sont pas ajoutées implicitement.
- [ ] Les dates invalides retournent 400.
- [ ] Un manager ou un site inconnu retourne 404.
- [ ] Les journées futures sont refusées.
- [ ] `PENDING`, `REST_DAY` et `UNDETERMINED` sont exclus du taux.
- [ ] Les présences en retard sont incluses dans le taux de présence.
- [ ] Les durées manquantes restent `null` dans le détail.
- [ ] Les sessions multiples d’une journée ne créent pas plusieurs journées.
- [ ] Les tests purs passent.
- [ ] Le typecheck du projet tenant passe.
- [ ] La réponse est comparée à des données réelles avant migration du frontend/PDF.
