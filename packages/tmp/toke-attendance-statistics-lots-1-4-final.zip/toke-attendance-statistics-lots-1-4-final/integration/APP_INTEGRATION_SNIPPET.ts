// 1. Ajouter avec les imports de routes dans src/tenant/app.ts
import attendanceStatisticsRoute from './routes/attendance.statistics.route.js';

// 2. Ajouter dans setupRoutes(), avant la route 404
this.app.use('/attendance/statistics', attendanceStatisticsRoute);
