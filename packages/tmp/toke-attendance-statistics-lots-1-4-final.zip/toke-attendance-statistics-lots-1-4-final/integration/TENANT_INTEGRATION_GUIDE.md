# Guide d’intégration tenant — Statistiques de pointage, lots 1 à 4

## 1. Objectif

Le paquet ajoute le nouvel endpoint :

```http
GET /attendance/statistics/overview
```

Il ne remplace pas immédiatement les anciennes routes sous `/statistique`. Les deux versions peuvent coexister pendant la recette.

## 2. Copie des fichiers

Depuis la racine du paquet, copier :

```text
src/tenant/modules/attendance-statistics/
    → <projet>/src/tenant/modules/attendance-statistics/

src/tenant/routes/attendance.statistics.route.ts
    → <projet>/src/tenant/routes/attendance.statistics.route.ts
```

## 3. Montage de la route

Appliquer `integration/app.ts.patch`, ou ajouter manuellement dans `src/tenant/app.ts` :

```ts
import attendanceStatisticsRoute from './routes/attendance.statistics.route.js';
```

Puis dans `setupRoutes()`, avant la route 404 :

```ts
this.app.use('/attendance/statistics', attendanceStatisticsRoute);
```

Le montage `/attendance/statistics` combiné à la route locale `/overview` donne exactement :

```http
GET /attendance/statistics/overview
```

## 4. Requête

```http
GET /attendance/statistics/overview
  ?manager=<manager_guid>
  &site=<site_guid_optionnel>
  &start_date=2026-08-01
  &end_date=2026-08-05
```

Règles :

- `manager` est obligatoire ;
- `site` est optionnel ;
- `start_date` et `end_date` doivent être fournis ensemble ;
- format strict `YYYY-MM-DD` ;
- aucune date future ;
- période maximale : 366 jours ;
- sans dates, la période va du premier jour du mois métier à aujourd’hui.

## 5. Périmètre d’équipe

Le périmètre est obtenu par :

```ts
OrgHierarchy.getAllTeamMembers(managerId)
```

Le paramètre `includeSudTeam` n’est pas activé. Le rapport contient donc uniquement les membres actuels de l’équipe du manager, conformément à la décision du projet. Les doublons sont supprimés par identifiant interne et les utilisateurs explicitement inactifs sont exclus.

## 6. Responsabilités

### Domaine

`attendance-day.ts` classe un couple `employé × journée métier`. Il ne connaît ni Sequelize, ni Express, ni `Date`.

### Agrégation

`attendance-overview.ts` calcule les taux, durées, répartitions et indicateurs de qualité uniquement à partir des journées déjà classifiées.

### Orchestration

`attendance-statistics.service.ts` :

1. charge l’équipe actuelle ;
2. valide le site via le port ;
3. charge toutes les sessions de la période en une requête ;
4. résout le planning de chaque employé et de chaque journée ;
5. construit la matrice complète `employé × jour` ;
6. appelle le domaine puis l’agrégateur.

### Adaptateur tenant

`tenant-attendance-statistics.adapter.ts` est le seul composant couplé aux classes existantes `User`, `OrgHierarchy`, `WorkSessions`, `Site`, à Sequelize et à `ScheduleResolutionService`.

### HTTP

Le contrôleur valide la requête, appelle le service et délègue le format de réponse à `R`. Aucun calcul métier n’est effectué dans la route ou le contrôleur.

## 7. Gestion des dates et heures

L’autorisation d’interroger le GUID demandé doit rester contrôlée par les middlewares d’authentification et d’habilitation du projet tenant. Le module ne déduit pas l’identité autorisée à partir d’une structure de requête qui n’a pas été fournie.

Le module n’utilise pas `new Date('YYYY-MM-DD')` pour construire les bornes métier. Cette écriture est interprétée comme UTC par JavaScript et peut déplacer la journée.

Les heures de pointage retournées par les classes existantes sont présentées avec :

```ts
date.toTimeString().slice(0, 8)
```

Elles ne sont pas reconverties par `toLocaleTimeString()` ou par un nouveau fuseau, car le serveur fournit déjà les heures préparées pour le fuseau métier.

## 8. Dépendances attendues

Le projet tenant doit déjà fournir :

- `@toke/shared` ;
- `express` ;
- `sequelize` ;
- les classes `User`, `OrgHierarchy`, `Site`, `WorkSessions` ;
- `ScheduleResolutionService` ;
- `Ensure` et `R`.

Aucune nouvelle dépendance npm n’est ajoutée.

## 9. Tests

Tests purs inclus :

```bash
rm -rf .attendance-statistics-test-dist

tsc -p tsconfig.core.json
node --test .attendance-statistics-test-dist/**/*.test.js
```

Dans le projet principal, exécuter ensuite le contrôle TypeScript et la suite de tests habituelle.

## 10. Tests d’intégration recommandés

1. Manager valide avec équipe et planning complet.
2. Manager valide avec équipe vide.
3. Manager inexistant : HTTP 404.
4. Site inexistant : HTTP 404.
5. Dates invalides, inversées, futures ou supérieures à 366 jours : HTTP 400.
6. Journée terminée sans session : `ABSENT`.
7. Journée en cours sans session : `PENDING`.
8. Présence sur repos : statut `REST_DAY` + issue `PRESENCE_ON_REST_DAY`.
9. Présence sans planning : statut `UNDETERMINED` + issue `PRESENCE_WITHOUT_SCHEDULE`.
10. Session ouverte ou durée absente : aucune durée fictive égale à zéro.
11. Plusieurs sessions le même jour : une seule journée agrégée.
12. Filtre site : seules les sessions du site sont prises en compte, sans modifier le planning attendu.
13. Session traversant minuit : vérifier son rattachement à la journée de démarrage selon les règles réelles du tenant.

## 11. Point de vigilance performance

Les sessions sont chargées en une requête. Les pauses sont ensuite lues par session via la méthode existante `getTotalPauseTime()` ; selon son implémentation, cela peut encore générer des requêtes supplémentaires. Ces lectures sont limitées à 8 opérations concurrentes afin de ne pas lancer un `Promise.all` non borné. La résolution actuelle des plannings reste cependant effectuée pour chaque couple `employé × date`, avec une concurrence limitée à 8. Cela protège la base contre un `Promise.all` massif, mais ne supprime pas le nombre de résolutions.

Une optimisation ultérieure devra ajouter une API de résolution en lot dans `ScheduleResolutionService`. Cette optimisation ne doit pas modifier les règles de classification du domaine.

## 12. Stratégie de déploiement

1. Déployer le nouveau module en parallèle de l’ancien endpoint.
2. Tester sur une période courte et comparer les journées une par une.
3. Vérifier les `UNDETERMINED` avant d’interpréter le taux.
4. Valider les résultats avec des données réelles du tenant.
5. Migrer le frontend et le PDF uniquement après validation.
6. Retirer l’ancienne route après recette et non avant.
