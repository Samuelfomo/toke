# Manifeste cumulatif des lots 1 à 4

## Lot 1 — Vérité journalière

Fichiers :

- `domain/attendance-day.types.ts`
- `domain/attendance-day.ts`
- `domain/attendance-day.test.ts`

Responsabilité : classifier un unique couple `employé × journée métier` sans accès à Express, Sequelize, PostgreSQL ou au fuseau.

## Lot 2 — Agrégation de la vue d’ensemble

Fichiers :

- `application/attendance-overview.types.ts`
- `application/attendance-overview.ts`
- `application/attendance-overview.test.ts`

Responsabilité : calculer les répartitions, taux, durées, anomalies et indicateurs de qualité à partir de journées déjà classifiées.

## Lot 3 — Contrat et exemple API

Fichiers :

- `docs/attendance-overview.contract.md`
- `examples/attendance-overview.response.json`

Responsabilité : figer les définitions, formules, unités, exclusions et risques d’interprétation de la réponse publique.

## Lot 4 — Intégration tenant complète

Fichiers :

- `application/attendance-statistics.ports.ts`
- `application/attendance-statistics.service.ts`
- `application/attendance-statistics.service.test.ts`
- `http/attendance-statistics.query.ts`
- `http/attendance-statistics.query.test.ts`
- `http/attendance-statistics.controller.ts`
- `infrastructure/postgres-interval.ts`
- `infrastructure/postgres-interval.test.ts`
- `infrastructure/tenant-attendance-statistics.adapter.ts`
- `src/tenant/routes/attendance.statistics.route.ts`
- `integration/app.ts.patch`
- `integration/TENANT_INTEGRATION_GUIDE.md`
- `integration/VALIDATION_CHECKLIST.md`

Responsabilité : récupérer l’équipe actuelle du manager, charger les sessions, résoudre les plannings, construire la matrice complète, valider la période et exposer `GET /attendance/statistics/overview`.

## Fichiers existants examinés pour l’intégration

Le lot 4 a été aligné sur les fichiers sources conservés du tenant, notamment :

- `attendance.stat.route.ts` ;
- `User.ts` ;
- `OrgHierarchy.ts` ;
- `WorkSessions.ts` ;
- `schedule.resolution.service.ts` ;
- `response.ts` ;
- `ensured-routes.ts` ;
- `app.ts` ;
- les structures Sequelize des utilisateurs, sessions, assignations et hiérarchie.

Ces fichiers de référence ne sont pas réécrits dans le paquet. Le livrable ajoute un module isolé et un patch de montage afin de réduire les risques de régression.
