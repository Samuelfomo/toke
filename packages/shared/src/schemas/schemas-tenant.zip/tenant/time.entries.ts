import { z } from 'zod';

import {
  PointageStatus,
  PointageType,
  TIME_ENTRIES_CODES,
  TIME_ENTRIES_DEFAULTS,
  TIME_ENTRIES_ERRORS,
  TIME_ENTRIES_VALIDATION,
  TimeEntryCode,
} from '../../constants/tenant/time.entries.js';
import { TimezoneConfigUtils } from '../../utils/timezone.config.validation.js';
import { paginationSchema } from '../country.js';

// Schema pour valider les adresses IP (IPv4 et IPv6)
const ipAddressSchema = z.string().refine((ip) => {
  // Regex simplifiée pour IPv4 et IPv6
  const ipv4Regex =
    /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  const ipv6Regex = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  return ipv4Regex.test(ip) || ipv6Regex.test(ip);
}, TIME_ENTRIES_ERRORS.IP_ADDRESS_INVALID);

// Schema pour les informations device (JSON)
const deviceInfoSchema = z.record(z.any()).refine((deviceInfo) => {
  try {
    JSON.stringify(deviceInfo);
    return true;
  } catch {
    return false;
  }
}, TIME_ENTRIES_ERRORS.DEVICE_INFO_INVALID);

const missionDataSchema = z.object({
  destination: z.string(),
  purpose: z.string(),
  expected_return: z.string().optional(),
  transport: z.string().optional(),
  authorization: z.string().optional(),
});

const validatedDataSchema = z.object({
  device_info: deviceInfoSchema.optional().nullable(),
  mission_data: missionDataSchema.optional().nullable(),
});

const persistedExternalIdSchema = z
  .string({
    invalid_type_error: TIME_ENTRIES_ERRORS.EXTERNAL_ID_INVALID,
  })
  .trim()
  .regex(/^[0-9A-HJKMNP-TV-Z]{26}$/i, TIME_ENTRIES_ERRORS.EXTERNAL_ID_INVALID)
  .transform((value) => value.toUpperCase());

// Compatibilité temporaire avec les clients déjà déployés :
// undefined, null et chaîne vide sont acceptés. L'API générera alors un ULID.
const externalIdInputSchema = z
  .preprocess(
    (value) => (typeof value === 'string' && value.trim() === '' ? undefined : value),
    persistedExternalIdSchema.optional().nullable(),
  )
  .transform((value) => value ?? undefined);

// Base schema pour les validations communes
const baseTimeEntriesSchema = z.object({
  external_id: externalIdInputSchema,

  user: z
    .string({
      required_error: TIME_ENTRIES_ERRORS.USER_REQUIRED,
      invalid_type_error: TIME_ENTRIES_ERRORS.USER_INVALID,
    })
    .min(TIME_ENTRIES_VALIDATION.USER.MIN_LENGTH, TIME_ENTRIES_ERRORS.USER_INVALID)
    .max(TIME_ENTRIES_VALIDATION.USER.MAX_LENGTH, TIME_ENTRIES_ERRORS.USER_INVALID)
    .trim(),

  device: z
    .string({
      required_error: TIME_ENTRIES_ERRORS.DEVICE_REQUIRED,
      invalid_type_error: TIME_ENTRIES_ERRORS.DEVICE_INVALID,
    })
    .min(TIME_ENTRIES_VALIDATION.DEVICE.MIN_LENGTH, TIME_ENTRIES_ERRORS.DEVICE_INVALID)
    .max(TIME_ENTRIES_VALIDATION.DEVICE.MAX_LENGTH, TIME_ENTRIES_ERRORS.DEVICE_INVALID)
    .trim(),

  site: z
    .string({
      required_error: TIME_ENTRIES_ERRORS.SITE_REQUIRED,
      invalid_type_error: TIME_ENTRIES_ERRORS.SITE_INVALID,
    })
    .min(TIME_ENTRIES_VALIDATION.SITE.MIN_LENGTH, TIME_ENTRIES_ERRORS.SITE_INVALID)
    .max(TIME_ENTRIES_VALIDATION.SITE.MAX_LENGTH, TIME_ENTRIES_ERRORS.SITE_INVALID)
    .trim(),

  pointage_type: z.nativeEnum(PointageType, {
    required_error: TIME_ENTRIES_ERRORS.POINTAGE_TYPE_REQUIRED,
    invalid_type_error: TIME_ENTRIES_ERRORS.POINTAGE_TYPE_INVALID,
  }),

  pointage_status: z
    .nativeEnum(PointageStatus, {
      invalid_type_error: TIME_ENTRIES_ERRORS.POINTAGE_STATUS_INVALID,
    })
    .default(TIME_ENTRIES_DEFAULTS.POINTAGE_STATUS),

  clocked_at: z
    .union([z.date(), z.string().transform((val) => new Date(val))], {
      required_error: TIME_ENTRIES_ERRORS.CLOCKED_AT_REQUIRED,
      invalid_type_error: TIME_ENTRIES_ERRORS.CLOCKED_AT_INVALID,
    })
    // .refine((date) => date <= TimezoneConfigUtils.getCurrentTime(), TIME_ENTRIES_ERRORS.FUTURE_POINTAGE),
    .refine((date) => {
      // Obtenir l'heure actuelle en timezone Africa/Douala
      const nowInDouala = new Date(
        TimezoneConfigUtils.getCurrentTime().toLocaleString('en-US', { timeZone: 'Africa/Douala' }),
      );
      return date <= nowInDouala;
    }, TIME_ENTRIES_ERRORS.FUTURE_POINTAGE),

  real_clocked_at: z
    .union([z.date(), z.string().transform((val) => new Date(val))], {
      invalid_type_error: TIME_ENTRIES_ERRORS.REAL_CLOCKED_AT_INVALID,
    })
    .optional()
    .nullable(),

  latitude: z
    .number({
      required_error: TIME_ENTRIES_ERRORS.LATITUDE_REQUIRED,
      invalid_type_error: TIME_ENTRIES_ERRORS.LATITUDE_INVALID,
    })
    .min(TIME_ENTRIES_VALIDATION.LATITUDE.MIN, TIME_ENTRIES_ERRORS.LATITUDE_INVALID)
    .max(TIME_ENTRIES_VALIDATION.LATITUDE.MAX, TIME_ENTRIES_ERRORS.LATITUDE_INVALID),

  longitude: z
    .number({
      required_error: TIME_ENTRIES_ERRORS.LONGITUDE_REQUIRED,
      invalid_type_error: TIME_ENTRIES_ERRORS.LONGITUDE_INVALID,
    })
    .min(TIME_ENTRIES_VALIDATION.LONGITUDE.MIN, TIME_ENTRIES_ERRORS.LONGITUDE_INVALID)
    .max(TIME_ENTRIES_VALIDATION.LONGITUDE.MAX, TIME_ENTRIES_ERRORS.LONGITUDE_INVALID),

  gps_accuracy: z
    .number({
      invalid_type_error: TIME_ENTRIES_ERRORS.GPS_ACCURACY_INVALID,
    })
    .int()
    .min(TIME_ENTRIES_VALIDATION.GPS_ACCURACY.MIN, TIME_ENTRIES_ERRORS.GPS_ACCURACY_INVALID)
    .max(TIME_ENTRIES_VALIDATION.GPS_ACCURACY.MAX, TIME_ENTRIES_ERRORS.GPS_ACCURACY_INVALID)
    .optional()
    .nullable(),

  qr_code: z
    .string({
      invalid_type_error: TIME_ENTRIES_ERRORS.QR_CODE_INVALID,
    })
    .min(TIME_ENTRIES_VALIDATION.QR_CODE.MIN_LENGTH, TIME_ENTRIES_ERRORS.QR_CODE_INVALID)
    .max(TIME_ENTRIES_VALIDATION.QR_CODE.MAX_LENGTH, TIME_ENTRIES_ERRORS.QR_CODE_INVALID)
    .optional()
    .nullable(),

  device_info: deviceInfoSchema.optional().nullable(),
  // validatedDataSchema,

  ip_address: ipAddressSchema.optional().nullable(),

  created_offline: z
    .boolean({
      invalid_type_error: TIME_ENTRIES_ERRORS.CREATED_OFFLINE_INVALID,
    })
    .default(TIME_ENTRIES_DEFAULTS.CREATED_OFFLINE),

  local_id: z
    .string({
      invalid_type_error: TIME_ENTRIES_ERRORS.LOCAL_ID_INVALID,
    })
    .min(TIME_ENTRIES_VALIDATION.LOCAL_ID.MIN_LENGTH, TIME_ENTRIES_ERRORS.LOCAL_ID_INVALID)
    .max(TIME_ENTRIES_VALIDATION.LOCAL_ID.MAX_LENGTH, TIME_ENTRIES_ERRORS.LOCAL_ID_INVALID)
    .trim()
    .optional()
    .nullable(),

  sync_attempts: z
    .number({
      invalid_type_error: TIME_ENTRIES_ERRORS.SYNC_ATTEMPTS_INVALID,
    })
    .int()
    .min(TIME_ENTRIES_VALIDATION.SYNC_ATTEMPTS.MIN, TIME_ENTRIES_ERRORS.SYNC_ATTEMPTS_INVALID)
    .max(TIME_ENTRIES_VALIDATION.SYNC_ATTEMPTS.MAX, TIME_ENTRIES_ERRORS.SYNC_ATTEMPTS_INVALID)
    .default(TIME_ENTRIES_DEFAULTS.SYNC_ATTEMPTS),

  last_sync_attempt: z
    .union([z.date(), z.string().transform((val) => new Date(val))], {
      invalid_type_error: TIME_ENTRIES_ERRORS.LAST_SYNC_ATTEMPT_INVALID,
    })
    .optional()
    .nullable(),

  memo: z
    .number({
      invalid_type_error: TIME_ENTRIES_ERRORS.MEMO_INVALID,
    })
    .int()
    .min(TIME_ENTRIES_VALIDATION.MEMO.MIN, TIME_ENTRIES_ERRORS.MEMO_INVALID)
    .max(TIME_ENTRIES_VALIDATION.MEMO.MAX, TIME_ENTRIES_ERRORS.MEMO_INVALID)
    .optional()
    .nullable(),

  correction_reason: z
    .string({
      invalid_type_error: TIME_ENTRIES_ERRORS.CORRECTION_REASON_INVALID,
    })
    .min(
      TIME_ENTRIES_VALIDATION.CORRECTION_REASON.MIN_LENGTH,
      TIME_ENTRIES_ERRORS.CORRECTION_REASON_INVALID,
    )
    .max(
      TIME_ENTRIES_VALIDATION.CORRECTION_REASON.MAX_LENGTH,
      TIME_ENTRIES_ERRORS.CORRECTION_REASON_INVALID,
    )
    .trim()
    .optional()
    .nullable(),

  image_url: z
    .string({
      invalid_type_error: TIME_ENTRIES_ERRORS.IMAGE_URL_INVALID,
    })
    .min(TIME_ENTRIES_VALIDATION.IMAGE_URL.MIN_LENGTH, TIME_ENTRIES_ERRORS.IMAGE_URL_INVALID)
    .max(TIME_ENTRIES_VALIDATION.IMAGE_URL.MAX_LENGTH, TIME_ENTRIES_ERRORS.IMAGE_URL_INVALID)
    .trim()
    .optional()
    .nullable(),

  is_fallback_checkin: z
    .boolean({
      invalid_type_error: TIME_ENTRIES_ERRORS.IS_FALLBACK_CHECKIN,
    })
    .default(TIME_ENTRIES_DEFAULTS.IS_FALLBACK_CHECKIN),
});

// Schema avec validations métier complexes
const timeEntriesWithValidation = baseTimeEntriesSchema.refine(
  (data) => {
    // Si le statut est "corrected", une raison de correction est requise
    if (data.pointage_status === PointageStatus.CORRECTED && !data.correction_reason) {
      return false;
    }
    return true;
  },
  {
    message: TIME_ENTRIES_ERRORS.CORRECTION_REASON_REQUIRED,
    path: ['correction_reason'],
  },
);

// Schema pour la création - tous les champs requis
export const createTimeEntriesSchema = timeEntriesWithValidation;

// Schema pour les mises à jour - tous les champs optionnels
export const updateTimeEntriesSchema = baseTimeEntriesSchema.partial();

export const fallbackCheckinQuerySchema = paginationSchema.extend({
  start_date: z.coerce.date().optional(),
  end_date: z.coerce.date().optional(),
});

// Schema pour les filtres
export const timeEntriesFiltersSchema = z
  .object({
    session: z.number().int().optional(),
    user: z.number().int().optional(),
    device: z.number().int().optional(),
    site: z.number().int().optional(),
    pointage_type: z.nativeEnum(PointageType).optional(),
    pointage_status: z.nativeEnum(PointageStatus).optional(),
    clocked_at_from: z.union([z.date(), z.string().transform((val) => new Date(val))]).optional(),
    clocked_at_to: z.union([z.date(), z.string().transform((val) => new Date(val))]).optional(),
    created_offline: z.boolean().optional(),
    has_memo: z.boolean().optional(),
    has_qr_code: z.boolean().optional(),
    needs_sync: z.boolean().optional(), // Pour les entrées créées offline
    gps_accuracy_min: z.number().optional(),
    gps_accuracy_max: z.number().optional(),
    pending_only: z.boolean().optional(), // Pour les entrées en attente
  })
  .strict();

// Schema pour validation GUID
export const timeEntriesGuidSchema = z
  .string()
  .min(TIME_ENTRIES_VALIDATION.GUID.MIN_LENGTH, TIME_ENTRIES_ERRORS.GUID_INVALID)
  .max(TIME_ENTRIES_VALIDATION.GUID.MAX_LENGTH, TIME_ENTRIES_ERRORS.GUID_INVALID);

// Constante partagée pour le mapping field -> code
const FIELD_TO_CODE_MAP: Record<string, TimeEntryCode> = {
  latitude: TIME_ENTRIES_CODES.LATITUDE_INVALID,
  longitude: TIME_ENTRIES_CODES.LONGITUDE_INVALID,
  pointage_type: TIME_ENTRIES_CODES.POINTAGE_TYPE_INVALID,
  clocked_at: TIME_ENTRIES_CODES.CLOCKED_AT_INVALID,
  site: TIME_ENTRIES_CODES.SITE_INVALID,
  user: TIME_ENTRIES_CODES.USER_INVALID,
  device: TIME_ENTRIES_CODES.DEVICE_INVALID,
  gps_accuracy: TIME_ENTRIES_CODES.GPS_ACCURACY_INVALID,
  qr_code: TIME_ENTRIES_CODES.QR_CODE_INVALID,
  device_info: TIME_ENTRIES_CODES.DEVICE_INFO_INVALID,
  ip_address: TIME_ENTRIES_CODES.IP_ADDRESS_INVALID,
  correction_reason: TIME_ENTRIES_CODES.CORRECTION_REASON_INVALID,
  real_clocked_at: TIME_ENTRIES_CODES.REAL_CLOCKED_AT_INVALID,
  pointage_status: TIME_ENTRIES_CODES.POINTAGE_STATUS_INVALID,
  created_offline: TIME_ENTRIES_CODES.CREATED_OFFLINE_INVALID,
  external_id: TIME_ENTRIES_CODES.EXTERNAL_ID_INVALID,
  local_id: TIME_ENTRIES_CODES.LOCAL_ID_INVALID,
  sync_attempts: TIME_ENTRIES_CODES.SYNC_ATTEMPTS_INVALID,
  last_sync_attempt: TIME_ENTRIES_CODES.LAST_SYNC_ATTEMPT_INVALID,
  memo: TIME_ENTRIES_CODES.MEMO_INVALID,
};

// Fonction de validation pour la création
export const validateTimeEntriesCreation = (data: any) => {
  const result = createTimeEntriesSchema.safeParse(data);

  if (!result.success) {
    const firstError = result.error.issues[0]!;
    const field = firstError.path[0] as string;

    const error: any = new Error(firstError.message);
    error.code = FIELD_TO_CODE_MAP[field] || TIME_ENTRIES_CODES.VALIDATION_FAILED;
    throw error;
  }

  return result.data;
};

// Fonction de validation pour la mise à jour
export const validateTimeEntriesUpdate = (data: any) => {
  const result = updateTimeEntriesSchema.safeParse(data);

  if (!result.success) {
    const firstError = result.error.issues[0]!;
    const field = firstError.path[0] as string;

    const error: any = new Error(firstError.message);
    error.code = FIELD_TO_CODE_MAP[field] || TIME_ENTRIES_CODES.VALIDATION_FAILED;
    throw error;
  }

  return result.data;
};

export const validateTimeEntriesFilters = (data: any) => {
  const result = timeEntriesFiltersSchema.safeParse(data);

  if (!result.success) {
    const firstError = result.error.issues[0]!;
    const field = firstError.path[0] as string;

    const error: any = new Error(firstError.message);
    error.code = TIME_ENTRIES_CODES.FILTER_INVALID; // Code générique pour les filtres
    throw error;
  }

  return result.data;
};

export const validateTimeEntriesGuid = (guid: any) => {
  const result = timeEntriesGuidSchema.safeParse(guid);

  if (!result.success) {
    const error: any = new Error(TIME_ENTRIES_ERRORS.GUID_INVALID);
    error.code = TIME_ENTRIES_CODES.INVALID_GUID;
    throw error;
  }

  return result.data;
};

export const validatePointageStatusTransition = (
  currentStatus: PointageStatus,
  newStatus: PointageStatus,
) => {
  const validTransitions: Record<PointageStatus, PointageStatus[]> = {
    [PointageStatus.DRAFT]: [PointageStatus.PENDING],
    [PointageStatus.PENDING]: [
      PointageStatus.ACCEPTED,
      PointageStatus.REJECTED,
      PointageStatus.CORRECTED,
    ],
    [PointageStatus.ACCEPTED]: [PointageStatus.ACCOUNTED, PointageStatus.CORRECTED],
    [PointageStatus.CORRECTED]: [PointageStatus.ACCEPTED, PointageStatus.REJECTED],
    [PointageStatus.ACCOUNTED]: [], // Aucune transition autorisée depuis accounted
    [PointageStatus.REJECTED]: [PointageStatus.CORRECTED],
  };

  if (!validTransitions[currentStatus].includes(newStatus)) {
    const error: any = new Error(TIME_ENTRIES_ERRORS.STATUS_TRANSITION_INVALID);
    error.code = TIME_ENTRIES_CODES.STATUS_TRANSITION_INVALID;
    throw error;
  }

  return true;
};

export const validatePointageSequence = (
  pointageType: PointageType,
  previousEntries: PointageType[],
) => {
  const lastEntry = previousEntries[previousEntries.length - 1];

  switch (pointageType) {
    case PointageType.CLOCK_OUT:
      if (lastEntry !== PointageType.CLOCK_IN && lastEntry !== PointageType.PAUSE_END) {
        const error: any = new Error(TIME_ENTRIES_ERRORS.CLOCK_OUT_WITHOUT_CLOCK_IN);
        error.code = TIME_ENTRIES_CODES.CLOCK_OUT_WITHOUT_CLOCK_IN;
        throw error;
      }
      break;

    case PointageType.PAUSE_START:
    case PointageType.PAUSE_END:
      if (!previousEntries.includes(PointageType.CLOCK_IN)) {
        const error: any = new Error(TIME_ENTRIES_ERRORS.PAUSE_WITHOUT_CLOCK_IN);
        error.code = TIME_ENTRIES_CODES.PAUSE_WITHOUT_CLOCK_IN;
        throw error;
      }
      break;

    case PointageType.CLOCK_IN:
      if (lastEntry === PointageType.CLOCK_IN || lastEntry === PointageType.PAUSE_START) {
        const error: any = new Error(TIME_ENTRIES_ERRORS.CLOCK_IN_WITHOUT_CLOCK_OUT);
        error.code = TIME_ENTRIES_CODES.CLOCK_IN_WITHOUT_CLOCK_OUT;
        throw error;
      }
      break;
  }

  return true;
};

// Schema complet pour les réponses (avec métadonnées)
export const timeEntriesResponseSchema = baseTimeEntriesSchema.extend({
  external_id: persistedExternalIdSchema.optional().nullable(),
  id: z.number().int().positive(),
  guid: z.string(),
  created_at: z.string().datetime(),
  updated_at: z.string().datetime(),
});

export const createWaypointSchema = z.object({
  external_id: externalIdInputSchema,
  // === IDENTIFICATION ===
  user: z
    .string()
    .min(TIME_ENTRIES_VALIDATION.USER.MIN_LENGTH)
    .max(TIME_ENTRIES_VALIDATION.USER.MAX_LENGTH)
    .trim(),

  device: z
    .string()
    .min(TIME_ENTRIES_VALIDATION.DEVICE.MIN_LENGTH)
    .max(TIME_ENTRIES_VALIDATION.DEVICE.MAX_LENGTH)
    .trim(),

  // === TYPE RESTREINT ===
  pointage_type: z.literal(PointageType.WAYPOINT, {
    required_error: 'pointage_type is required and must be "waypoint"',
    invalid_type_error: 'pointage_type must be "waypoint" for this endpoint',
  }),

  // === SITE OPTIONNEL ===
  site: z
    .string()
    .min(TIME_ENTRIES_VALIDATION.SITE.MIN_LENGTH)
    .max(TIME_ENTRIES_VALIDATION.SITE.MAX_LENGTH)
    .trim()
    .optional()
    .nullable(),

  // === LIBELLÉ LIBRE DU LIEU ===
  site_name: z
    .string()
    .min(1, 'Label must be at least 1 character')
    .max(255, 'Label must be at most 255 characters')
    .trim()
    .optional()
    .nullable(),

  // === HORODATAGE ===
  clocked_at: z
    .union([z.date(), z.string().transform((val) => new Date(val))], {
      required_error: 'clocked_at is required',
      invalid_type_error: 'clocked_at must be a valid date',
    })
    .refine((date) => {
      const nowInDouala = TimezoneConfigUtils.getCurrentTime();
      return date <= nowInDouala;
    }, 'clocked_at cannot be in the future'),

  // === GPS (requis) ===
  latitude: z
    .number({
      required_error: 'latitude is required',
      invalid_type_error: 'latitude must be a number',
    })
    .min(TIME_ENTRIES_VALIDATION.LATITUDE.MIN)
    .max(TIME_ENTRIES_VALIDATION.LATITUDE.MAX),

  longitude: z
    .number({
      required_error: 'longitude is required',
      invalid_type_error: 'longitude must be a number',
    })
    .min(TIME_ENTRIES_VALIDATION.LONGITUDE.MIN)
    .max(TIME_ENTRIES_VALIDATION.LONGITUDE.MAX),

  gps_accuracy: z
    .number({ invalid_type_error: 'gps_accuracy must be an integer' })
    .int()
    .min(TIME_ENTRIES_VALIDATION.GPS_ACCURACY.MIN)
    .max(TIME_ENTRIES_VALIDATION.GPS_ACCURACY.MAX)
    .optional()
    .nullable(),

  // === DEVICE INFO ===
  device_info: deviceInfoSchema.optional().nullable(),

  // === RÉSEAU ===
  ip_address: ipAddressSchema.optional().nullable(),

  // === OFFLINE ===
  created_offline: z
    .boolean({ invalid_type_error: 'created_offline must be a boolean' })
    .default(false),

  local_id: z
    .string({ invalid_type_error: 'local_id must be a string' })
    .min(TIME_ENTRIES_VALIDATION.LOCAL_ID.MIN_LENGTH)
    .max(TIME_ENTRIES_VALIDATION.LOCAL_ID.MAX_LENGTH)
    .trim()
    .optional()
    .nullable(),

  sync_attempts: z
    .number({ invalid_type_error: 'sync_attempts must be an integer' })
    .int()
    .min(TIME_ENTRIES_VALIDATION.SYNC_ATTEMPTS.MIN)
    .max(TIME_ENTRIES_VALIDATION.SYNC_ATTEMPTS.MAX)
    .default(0),

  last_sync_attempt: z
    .union([z.date(), z.string().transform((val) => new Date(val))], {
      invalid_type_error: 'last_sync_attempt must be a valid date',
    })
    .optional()
    .nullable(),
});

// === FONCTION DE VALIDATION ===

export const validateWaypointCreation = (data: any) => {
  const result = createWaypointSchema.safeParse(data);

  if (!result.success) {
    const firstError = result.error.issues[0]!;
    const field = firstError.path[0] as string;
    const error: any = new Error(firstError.message);
    error.code =
      field === 'external_id'
        ? TIME_ENTRIES_CODES.EXTERNAL_ID_INVALID
        : `waypoint_${field || 'validation'}_invalid`;
    throw error;
  }

  return result.data;
};

// === TYPES TS ===
export type CreateWaypointInput = z.infer<typeof createWaypointSchema>;

// Export groupé pour faciliter les imports
export const timeEntriesSchemas = {
  validateTimeEntriesCreation,
  validateTimeEntriesUpdate,
  validateTimeEntriesFilters,
  validateTimeEntriesGuid,
  validatePointageStatusTransition,
  validatePointageSequence,
  createTimeEntriesSchema,
  updateTimeEntriesSchema,
  timeEntriesFiltersSchema,
  timeEntriesGuidSchema,
};

// Types TypeScript générés à partir des schemas
export type CreateTimeEntriesInput = z.infer<typeof createTimeEntriesSchema>;
export type UpdateTimeEntriesInput = z.infer<typeof updateTimeEntriesSchema>;
export type TimeEntriesData = z.infer<typeof timeEntriesResponseSchema>;
export type TimeEntriesFilters = z.infer<typeof timeEntriesFiltersSchema>;
export type DeviceInfo = z.infer<typeof deviceInfoSchema>;
