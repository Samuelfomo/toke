import { createApiClient } from '@toke/api/dist/utils/axios.config.js';

export default class TenantOnboardingService {
  static async forward(
    action: 'status' | 'subscribe' | 'payment-methods' | 'estimate',
    token: string,
    body: unknown,
  ) {
    const base =
      process.env.NODE_ENV === 'development'
        ? `https://${process.env.MST_HOST}`
        : `http://${process.env.HOST}:${process.env.MST_PORT}`;
    const api = createApiClient(base, process.env.SECRET_KEY, process.env.API_KEY);
    const config = { headers: { 'x-onboarding-token': token }, timeout: 15000 };
    try {
      const r =
        action === 'status' || action === 'payment-methods'
          ? await api.get('/tenant-onboarding/' + action, config)
          : await api.post('/tenant-onboarding/' + action, body, config);
      return { status: r.status, data: r.data };
    } catch (e: any) {
      const status = e.response?.status;
      if (Number.isInteger(status) && status >= 400 && status < 500)
        return { status, data: e.response.data };
      return {
        status: 503,
        data: {
          success: false,
          error: {
            code: 'onboarding_unavailable',
            message: 'Consult status before retrying with the same key',
          },
        },
      };
    }
  }
}
