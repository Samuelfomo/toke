/**
 * Contrat frontend de GET /attendance/statistics/overview.
 *
 * IMPORTANT : ce fichier reflète le contrat backend v2.3 (preuve de présence + E+/E-).
 * Il ne doit contenir aucun recalcul métier des statuts ou des taux.
 */

export type BusinessDate = string;

export const ATTENDANCE_STATUSES = [
  'PRESENT',
  'LATE',
  'ABSENT',
  'REST_DAY',
  'UNDETERMINED',
  'PENDING',
] as const;

export type AttendanceStatus = (typeof ATTENDANCE_STATUSES)[number];

export const ATTENDANCE_ISSUES = [
  'PRESENCE_ON_REST_DAY',
  'PRESENCE_WITHOUT_SCHEDULE',
  'MISSING_SCHEDULE',
  'INVALID_SCHEDULE',
  'OPEN_SESSION',
  'INCOMPLETE_SESSION',
  'MISSING_DURATION',
  'ACTIVITY_OUTSIDE_EXPECTED_BLOCK',
  'CORRECTED_PRESENCE',
] as const;

export type AttendanceIssue = (typeof ATTENDANCE_ISSUES)[number];

export interface AttendanceOverviewPeriod {
  startDate: BusinessDate;
  endDate: BusinessDate;
  dayCount: number;
}

export interface AttendanceOverviewScopeEmployee {
  guid: string;
  name: string;
}

export interface AttendanceOverviewScope {
  managerGuid: string;
  siteGuid: string | null;
  teamSize: number;
  employees: AttendanceOverviewScopeEmployee[];
}

export type AttendanceStatusTotals = Record<AttendanceStatus, number>;

export interface AttendanceRateMetrics {
  employeeWorkingDaysExpected: number;
  attendedWorkingDays: number;
  onTimeWorkingDays: number;
  lateWorkingDays: number;
  absentWorkingDays: number;
  attendanceRate: number | null;
  punctualityRate: number | null;
  absenceRate: number | null;
  lateRate: number | null;
  employeeDaysAnalyzed: number;
  employeeDaysWithIssues: number;
  issueRate: number | null;
}

export interface AttendanceAdoptionMetrics {
  coveredFinalizedOperations: number;
  completeOperations: number;
  incompleteOperations: number;
  undeterminedOperations: number;
  evaluatedOperations: number;
  adoptionRate: number | null;
}

export type AttendanceAdoptionState = 'COMPLETE' | 'INCOMPLETE' | 'UNDETERMINED' | 'NOT_ELIGIBLE' | 'CONTINUATION';

export interface AttendanceDurationMetrics {
  expectedWorkMinutes: number;
  grossMinutes: number;
  pauseMinutes: number;
  netMinutes: number;
  daysWithKnownGrossDuration: number;
  daysWithKnownPauseDuration: number;
  daysWithKnownNetDuration: number;
  daysWithMissingDuration: number;
  daysWithKnownExpectedWorkDuration: number;
  /** Durée réellement attribuée aux occurrences de planning comparables. */
  attributedWorkMinutes: number;
  /** Somme signée des écarts occurrence par occurrence. */
  rawDeltaMinutes: number;
  /** E+ retenu selon la politique de planification. */
  creditedExtraMinutes: number;
  /** Surplus réel au-delà du plafond E+ autorisé. */
  excessBeyondExtraMinutes: number;
  /** Déficit cumulé sur les occurrences comparables. */
  deficitMinutes: number;
  /** Nombre d'occurrences disposant d'une durée attribuée calculable. */
  occurrencesWithKnownAttributedWorkDuration: number;
  /** Nombre d'occurrences disposant d'un écart E+/E- calculable. */
  occurrencesWithKnownDelta: number;
  /** Nombre d'occurrences pour lesquelles la politique E+ est résolue. */
  occurrencesWithResolvedExtraPolicy: number;
}

export interface AttendanceIssueOccurrence {
  employeeGuid: string;
  employeeName: string;
  date: BusinessDate;
  status: AttendanceStatus;
  sourceContext: AttendanceSourceContext;
}

export interface AttendanceSourceContext {
  sessionGuids: string[];
  clockInEntryGuids: string[];
}

export interface AttendanceIssueSummary {
  issue: AttendanceIssue;
  count: number;
  employeesConcerned: number;
  occurrences: AttendanceIssueOccurrence[];
}

export interface AttendanceDailyOverview {
  date: BusinessDate;
  teamSize: number;
  statusTotals: AttendanceStatusTotals;
  rates: AttendanceRateMetrics;
  /**
   * Durées agrégées de la journée retournées par l'API.
   * Optionnel uniquement pour permettre un déploiement frontend avant le backend enrichi.
   */
  durations?: AttendanceDurationMetrics;
  adoption?: AttendanceAdoptionMetrics;
  issueCount: number;
}

export interface AttendanceEmployeeDayOverview {
  date: BusinessDate;
  status: AttendanceStatus;
  rateEligible: boolean;
  adoption?: AttendanceAdoptionState;
  adoptionOperationId?: string | null;
  adoptionSessionGuid?: string | null;
  /** Retard réel après déduction de la tolérance du planning. */
  delayMinutes: number | null;
  /** Écart brut entre l'heure d'arrivée et l'heure théorique. */
  arrivalDelayMinutes: number | null;
  /** Tolérance de retard autorisée par le planning du jour. */
  toleranceMinutes: number | null;
  /** Durée de travail attendue pour l'occurrence, calculée par le backend. */
  expectedWorkMinutes: number | null;
  /** Portion de la durée réellement enregistrée que le backend rattache à cette occurrence. */
  attributedWorkMinutes: number | null;
  /** Écart signé : attributedWorkMinutes - expectedWorkMinutes. */
  rawDeltaMinutes: number | null;
  /** Déficit de durée pour cette occurrence. */
  deficitMinutes: number | null;
  /** E+ retenu après application de la politique de planification. */
  creditedExtraMinutes: number | null;
  /** Surplus réel au-delà du plafond E+ autorisé. */
  excessBeyondExtraMinutes: number | null;
  /** Politique E+ résolue pour cette occurrence. */
  extraAllowed: boolean | null;
  /** Plafond E+ de l'occurrence, en minutes. */
  extraMaxMinutes: number | null;
  /** Heure métier déjà préparée par le serveur : HH:mm ou HH:mm:ss. */
  firstClockIn: string | null;
  /** Date métier correspondant à la première entrée. */
  firstClockInDate: BusinessDate | null;
  /** Heure métier déjà préparée par le serveur : HH:mm ou HH:mm:ss. */
  lastClockOut: string | null;
  /** Date métier correspondant à la dernière sortie. */
  lastClockOutDate: BusinessDate | null;
  grossMinutes: number | null;
  pauseMinutes: number | null;
  netMinutes: number | null;
  issues: AttendanceIssue[];
  sourceContext: AttendanceSourceContext;
}

export interface AttendanceEmployeeOverview {
  employeeGuid: string;
  employeeName: string;
  statusTotals: AttendanceStatusTotals;
  rates: AttendanceRateMetrics;
  adoption?: AttendanceAdoptionMetrics;
  durations: AttendanceDurationMetrics;
  issueCount: number;
  days: AttendanceEmployeeDayOverview[];
}

export interface AttendanceDataQuality {
  unresolvedScheduleDays: number;
  presenceWithoutScheduleDays: number;
  openSessionDays: number;
  incompleteSessionDays: number;
  missingDurationDays: number;
  correctedPresenceDays: number;
  reliableForAttendanceRate: boolean;
  notes: string[];
}

export interface AttendanceOverview {
  generatedAt: string;
  period: AttendanceOverviewPeriod;
  scope: AttendanceOverviewScope;
  summary: {
    statusTotals: AttendanceStatusTotals;
    rates: AttendanceRateMetrics;
    adoption?: AttendanceAdoptionMetrics;
    durations: AttendanceDurationMetrics;
    issueCount: number;
  };
  daily: AttendanceDailyOverview[];
  employees: AttendanceEmployeeOverview[];
  issues: AttendanceIssueSummary[];
  dataQuality: AttendanceDataQuality;
}

export interface AttendanceStatisticsFilters {
  managerGuid: string;
  siteGuid: string | null;
  startDate: BusinessDate;
  endDate: BusinessDate;
}

export interface AttendanceStatisticsQueryParams {
  manager: string;
  start_date: BusinessDate;
  end_date: BusinessDate;
  site?: string;
}

export interface ApiSuccessEnvelope<T> {
  success: true;
  data: T;
  timestamp?: string;
}

export interface ApiErrorPayload {
  code: string;
  message: string;
  field?: string;
  details?: unknown;
}

export interface ApiErrorEnvelope {
  success: false;
  error: ApiErrorPayload;
  timestamp?: string;
}

export type AttendanceDataQualityLevel = 'reliable' | 'warning' | 'unreliable';

export interface AttendanceStatisticsValidationError {
  code:
    | 'manager_required'
    | 'invalid_date_format'
    | 'invalid_date_value'
    | 'invalid_date_range'
    | 'future_date_not_allowed'
    | 'period_too_large';
  message: string;
  field?: 'managerGuid' | 'startDate' | 'endDate';
}
