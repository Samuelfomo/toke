<template>
  <div class="space-y-6">
    <PlanningPageHeader
        eyebrow="Contrôle avant publication"
        :title="suggestion
                ? `Suggestion du ${formatDate(suggestion.period_from)} au ${formatDate(suggestion.period_to)}`
                : 'Aperçu de la suggestion'"
        description="Vérifiez la couverture, l’équité, les gardes, les congés et les affectations avant de publier le planning officiel."
    >
      <template #actions>
        <button
            class="secondary-button"
            @click="router.push({ name: 'planning-suggestion-list' })"
        >
          <IconArrowLeft :size="16" />
          Retour
        </button>

        <button
            v-if="suggestion?.status === 'draft'"
            class="primary-button"
            @click="openBulkEditor"
        >
          <IconEdit :size="16" />
          Ajuster le planning
        </button>

        <button
            v-if="suggestion?.status === 'draft'"
            class="secondary-button"
            :disabled="actionLoading"
            @click="confirmAction = 'regenerate'"
        >
          <IconRefresh :size="16" />
          Régénérer autour des décisions
        </button>

      </template>
    </PlanningPageHeader>

    <PlanningInfoPanel
        v-if="errorMessage"
        tone="warning"
        title="Chargement impossible"
        :description="errorMessage"
    />

    <PlanningInfoPanel
        v-if="suggestion?.status === 'draft' && publicationWarning"
        tone="warning"
        title="Alertes à confirmer avant publication"
        :description="publicationWarning"
        important="Ces écarts signalent ce qui mérite votre attention. Vous gardez la décision finale lorsque la publication reste autorisée."
    />

    <PlanningInfoPanel
        v-if="suggestion?.diagnostics.regeneration?.warningCount"
        tone="info"
        title="Régénération avec décisions managériales"
        :description="`${suggestion.diagnostics.regeneration.warningCount} avertissement(s) ont été conservés pendant la dernière régénération.`"
        important="Les décisions manuelles restent prioritaires. Les avertissements indiquent seulement les écarts avec les règles définies."
    />

    <div v-if="loading" class="space-y-4">
      <div class="h-28 animate-pulse rounded-2xl bg-slate-100" />
      <div class="h-96 animate-pulse rounded-2xl bg-slate-100" />
    </div>

    <template v-else-if="suggestion">
      <SuggestionIssueSummary
          :hard-count="hardViolations.length"
          :below-minimum-count="belowMinimumCoverage.length"
          :warning-count="warningViolations.length"
          :manual-count="manualCellCount"
          :unassigned-count="unassignedCellCount"
          @open="activeTab = $event"
          @filter-manual="activateManualFilter"
          @filter-unassigned="activateUnassignedFilter"
      />

      <section class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div class="grid gap-px bg-slate-100 sm:grid-cols-2 xl:grid-cols-4">
          <Score
              label="Conformité globale"
              description="Synthèse des objectifs et contraintes respectés."
              :value="suggestion.conformity_score"
          />
          <Score
              label="Couverture"
              description="Niveau d’atteinte des effectifs demandés."
              :value="suggestion.diagnostics.coverageScore"
          />
          <Score
              label="Équité"
              description="Répartition des contraintes entre collaborateurs."
              :value="suggestion.diagnostics.fairnessScore"
          />
          <Info
              label="Collaborateurs"
              :value="String(suggestion.items.length)"
          />
        </div>
      </section>

      <PlanningInfoPanel
          v-if="generationScope?.temporaryExcludedEmployeeCount"
          tone="info"
          title="Exclusions temporaires appliquées"
          :description="`${generationScope.temporaryExcludedEmployeeCount} collaborateur(s) ne participent pas à cette proposition.`"
          :important="temporaryExcludedNames"
      />

      <PlanningInfoPanel
          v-if="historyReview?.warning"
          tone="warning"
          title="Historique d’équité indisponible"
          :description="historyReview.warning.message"
          important="La suggestion a été générée sans historique. Aucun problème historique n’a bloqué le calcul."
      />

      <PlanningInfoPanel
          v-if="historyReview?.anomalies?.length"
          tone="warning"
          title="Alertes sur l’historique d’équité"
          :description="`${historyReview.anomalies.length} anomalie(s) ont été détectées dans les plannings précédents.`"
          :important="historyReviewMessage"
      />

      <section
          v-if="guardPools.length"
          class="rounded-2xl border border-violet-100 bg-violet-50/30 p-5 shadow-sm"
      >
        <div class="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div class="flex items-start gap-3">
            <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-violet-100 text-violet-700">
              <IconUsersGroup :size="20" />
            </div>
            <div>
              <p class="text-xs font-bold uppercase tracking-[0.12em] text-violet-500">
                Gardes
              </p>
              <h2 class="mt-1 text-base font-bold text-slate-900">
                Équipes de garde par semaine
              </h2>
              <p class="mt-1 max-w-2xl text-xs leading-5 text-slate-600">
                Répartition proposée automatiquement à partir des règles de garde définies pour cette période.
              </p>
            </div>
          </div>

          <span class="w-fit rounded-full bg-violet-100 px-3 py-1 text-xs font-bold text-violet-700">
            {{ guardPools.length }} semaine(s)
          </span>
        </div>

        <div class="mt-5 grid gap-3 lg:grid-cols-2">
          <article
              v-for="pool in guardPools"
              :key="`${pool.weekFrom}-${pool.weekTo}`"
              class="rounded-xl border border-violet-100 bg-white p-4"
          >
            <div class="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p class="text-xs font-bold uppercase tracking-[0.12em] text-slate-400">
                  Semaine
                </p>
                <p class="mt-1 text-sm font-bold text-slate-900">
                  Du {{ formatDate(pool.weekFrom) }} au
                  {{ formatDate(pool.weekTo) }}
                </p>
              </div>

              <div class="flex flex-wrap gap-2">
                <span class="rounded-full bg-violet-50 px-2.5 py-1 text-xs font-bold text-violet-700">
                  Équipe de la semaine
                </span>
                <span class="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-bold text-slate-600">
                  {{ pool.selectionModeLabel }}
                </span>
              </div>
            </div>

            <div class="mt-4 space-y-2">
              <div
                  v-for="employee in pool.employees"
                  :key="employee.guid"
                  class="flex items-center gap-3 rounded-lg bg-slate-50 px-3 py-2.5"
              >
                <div
                    class="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-xs font-bold"
                    :class="employee.resolved
                            ? 'bg-slate-900 text-white'
                            : 'bg-amber-100 text-amber-700'"
                >
                  {{ employee.resolved ? initials(employee.name) : '?' }}
                </div>

                <div class="min-w-0">
                  <p
                      class="truncate text-xs font-bold"
                      :class="employee.resolved
                              ? 'text-slate-800'
                              : 'text-amber-800'"
                  >
                    {{ employee.name }}
                  </p>
<!--                  <p class="mt-0.5 truncate text-xs text-slate-400">-->
<!--                    {{ employee.employeeCode ?? employee.guid }}-->
<!--                  </p>-->
                </div>
              </div>

              <p
                  v-if="!pool.employees.length"
                  class="rounded-lg border border-dashed border-slate-200 px-3 py-4 text-center text-xs text-slate-400"
              >
                Aucun collaborateur dans ce pool.
              </p>
            </div>
          </article>
        </div>
      </section>

      <section class="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
        <div class="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div class="flex flex-wrap gap-x-4 gap-y-2">
            <Legend label="Horaire fixe" tone="indigo" />
            <Legend label="Service généré" tone="blue" />
            <Legend label="Garde / continuation" tone="violet" />
            <Legend label="Congé hebdomadaire" tone="rose" />
            <Legend label="Repos après garde" tone="amber" />
            <Legend label="Repos du modèle" tone="slate" />
            <Legend label="Non affecté" tone="empty" />
          </div>

          <div class="inline-flex rounded-xl border border-slate-200 p-1">
            <button
                class="tab-button"
                :class="activeTab === 'planning' ? 'active' : ''"
                @click="activeTab = 'planning'"
            >
              Planning
            </button>
            <button
                class="tab-button"
                :class="activeTab === 'coverage' ? 'active' : ''"
                @click="activeTab = 'coverage'"
            >
              Couverture
            </button>
            <button
                class="tab-button"
                :class="activeTab === 'issues' ? 'active' : ''"
                @click="activeTab = 'issues'"
            >
              Alertes {{ suggestion.diagnostics.violations.length }}
            </button>
          </div>
        </div>
      </section>

      <SuggestionFilters
          v-if="activeTab === 'planning'"
          :search="employeeSearch"
          :manual-only="manualOnly"
          :guard-only="guardOnly"
          :unassigned-only="unassignedOnly"
          :manual-count="manualCellCount"
          :guard-count="guardCellCount"
          :unassigned-count="unassignedCellCount"
          @update:search="employeeSearch = $event"
          @update:manualOnly="manualOnly = $event"
          @update:guardOnly="guardOnly = $event"
          @update:unassignedOnly="unassignedOnly = $event"
          @reset="resetPlanningFilters"
      />

      <section
          v-if="activeTab === 'planning'"
          class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm"
      >
        <div class="tf-scroll-area overflow-auto">
          <table
              class="border-collapse"
              style="min-width: max-content; width: 100%"
          >
            <thead class="sticky top-0 z-20">
            <tr class="border-b border-slate-200 bg-slate-50">
              <th class="sticky left-0 z-30 min-w-[220px] border-r border-slate-200 bg-slate-50 px-4 py-3 text-left text-xs font-bold uppercase tracking-[0.1em] text-slate-400">
                Collaborateur
              </th>

              <th
                  v-for="day in calendarDays"
                  :key="day.iso"
                  class="min-w-[108px] px-2 py-3 text-center"
                  :class="day.outsidePeriod
                                        ? 'bg-amber-50/60'
                                        : day.weekend
                                            ? 'bg-slate-100/70'
                                            : ''"
              >
                <p
                    class="text-xs font-bold uppercase"
                    :class="day.outsidePeriod
                                            ? 'text-amber-700'
                                            : 'text-slate-500'"
                >
                  {{ day.shortLabel }}
                </p>
                <p class="mt-0.5 text-xs text-slate-400">
                  {{ day.dayMonth }}
                </p>
                <p
                    v-if="day.outsidePeriod"
                    class="mt-1 text-xs font-bold uppercase text-amber-600"
                >
                  suite
                </p>
              </th>
            </tr>
            </thead>

            <tbody>
            <tr
                v-for="item in filteredItems"
                :key="item.guid"
                class="border-b border-slate-100 last:border-0"
            >
              <td class="sticky left-0 z-10 border-r border-slate-100 bg-white px-4 py-3">
                <div class="flex items-center gap-3">
                  <div class="flex h-9 w-9 items-center justify-center rounded-xl bg-slate-900 text-xs font-bold text-white">
                    {{ initials(item.user.name) }}
                  </div>
                  <div>
                    <p class="max-w-[150px] truncate text-xs font-bold text-slate-800">
                      {{ item.user.name }}
                    </p>
<!--                    <p class="mt-0.5 text-xs text-slate-400">-->
<!--                      {{ item.user.employee_code ?? 'Sans code' }}-->
<!--                    </p>-->
                  </div>
                </div>
              </td>

              <td
                  v-for="day in calendarDays"
                  :key="day.iso"
                  class="p-1.5 align-middle"
                  :class="day.weekend ? 'bg-slate-50/70' : ''"
              >
                <button
                    type="button"
                    class="cell-card"
                    :class="cellClasses(item, day.iso)"
                    :disabled="suggestion.status !== 'draft' || !(day.iso in item.schedule)"
                    @click="openCell(item, day.iso)"
                >
                                        <span class="block truncate text-xs font-bold">
                                            {{ cellLabel(item, day.iso) }}
                                        </span>
                  <span class="mt-1 block truncate text-xs opacity-70">
                                            {{ cellTime(item, day.iso) }}
                                        </span>
                  <span
                      v-if="isManual(item, day.iso)"
                      class="absolute right-1 top-1 h-1.5 w-1.5 rounded-full bg-orange-500"
                  />
                </button>
              </td>
            </tr>
            <tr v-if="filteredItems.length === 0">
              <td :colspan="calendarDays.length + 1" class="px-6 py-14 text-center">
                <p class="text-sm font-bold text-slate-700">Aucun collaborateur ne correspond aux filtres</p>
                <p class="mt-1 text-xs text-slate-500">Réinitialisez la recherche ou les filtres de contrôle.</p>
              </td>
            </tr>
            </tbody>
          </table>
        </div>
      </section>

      <section
          v-else-if="activeTab === 'coverage'"
          class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm"
      >
        <div class="tf-scroll-area overflow-x-auto">
          <table class="w-full min-w-[850px]">
            <thead class="bg-slate-50">
            <tr class="text-left text-xs font-bold uppercase text-slate-400">
              <th class="px-5 py-3">Date</th>
              <th class="px-4 py-3">Service</th>
              <th class="px-4 py-3">Mode</th>
              <th class="px-4 py-3">Minimum</th>
              <th class="px-4 py-3">Cible</th>
              <th class="px-4 py-3">Affectés</th>
              <th class="px-5 py-3">État</th>
            </tr>
            </thead>

            <tbody class="divide-y divide-slate-100">
            <tr
                v-for="coverage in sortedCoverage"
                :key="`${coverage.date}-${coverage.requirementGuid}`"
            >
              <td class="px-5 py-3 text-xs font-semibold text-slate-700">
                {{ formatDate(coverage.date) }}
              </td>
              <td class="px-4 py-3 text-xs text-slate-600">
                {{ coverage.templateName }}
              </td>
              <td class="px-4 py-3 text-xs text-slate-500">
                {{ ALLOCATION_LABELS[coverage.allocationMode] }}
              </td>
              <td class="px-4 py-3 text-xs text-slate-600">
                {{ coverage.minimum }}
              </td>
              <td class="px-4 py-3 text-xs text-slate-600">
                {{ coverage.target }}
              </td>
              <td class="px-4 py-3 text-xs font-bold text-slate-800">
                {{ coverage.assigned }}
              </td>
              <td class="px-5 py-3">
                                    <span
                                        class="rounded-full px-2 py-1 text-xs font-bold"
                                        :class="coverageClass(coverage.status)"
                                    >
                                        {{ coverageLabel(coverage.status) }}
                                    </span>
              </td>
            </tr>
            </tbody>
          </table>
        </div>
      </section>

      <section v-else class="space-y-3">
        <PlanningInfoPanel
            v-if="!suggestion.diagnostics.violations.length"
            tone="success"
            title="Aucune violation détectée"
            description="Aucun blocage ni avertissement n’a été détecté sur cette suggestion."
        />

        <article
            v-for="violation in sortedViolations"
            :key="`${violation.code}-${violation.date}-${violation.employeeGuid}`"
            class="rounded-2xl border p-4"
            :class="violation.severity === 'HARD'
                        ? 'border-red-200 bg-red-50'
                        : 'border-amber-200 bg-amber-50'"
        >
          <div class="flex items-start gap-3">
            <IconAlertTriangle
                :size="18"
                :class="violation.severity === 'HARD'
                                ? 'text-red-600'
                                : 'text-amber-600'"
            />
            <div>
              <div class="flex gap-2">
                <p class="text-xs font-bold text-slate-900">
                  {{ violation.severity === 'HARD' ? 'Blocage' : 'À vérifier' }}
                </p>
                <span
                    class="text-xs font-bold uppercase"
                    :class="violation.severity === 'HARD'
                                        ? 'text-red-700'
                                        : 'text-amber-700'"
                >
                                    {{ severityLabel(violation.severity) }}
                                </span>
              </div>
              <p class="mt-1 text-xs leading-5 text-slate-600">
                {{ violation.message }}
              </p>
              <p
                  v-if="violation.date"
                  class="mt-1 text-xs text-slate-400"
              >
                {{ formatDate(violation.date) }}
              </p>
            </div>
          </div>
        </article>
      </section>
    </template>

    <SuggestionPublicationBar
        v-if="suggestion?.status === 'draft'"
        :can-approve="canApprove"
        :warning="publicationWarning"
        :loading="actionLoading"
        @approve="confirmAction = 'approve'"
        @reject="confirmAction = 'reject'"
    />

    <SuggestionBulkEditor
        :open="bulkEditorOpen"
        :suggestion="suggestion"
        :templates="templates"
        :initial-item-guid="editorInitialItemGuid"
        :initial-iso="editorInitialIso"
        @close="closePlanningEditor"
        @saved="onBulkSaved"
    />

    <PlanningConfirmDialog
        :open="confirmAction !== null"
        :danger="confirmAction === 'reject'"
        :loading="actionLoading"
        :title="confirmAction === 'approve'
                ? 'Valider et publier ce planning ?'
                : confirmAction === 'regenerate'
                    ? 'Régénérer autour des décisions du manager ?'
                    : 'Rejeter cette suggestion ?'"
        :description="confirmAction === 'approve'
                ? 'Les affectations officielles seront créées pour les collaborateurs et remplaceront les affectations qui chevauchent la période.'
                : confirmAction === 'regenerate'
                    ? 'Toké conservera les cellules modifiées manuellement et recalculera uniquement les cellules encore automatiques.'
                    : 'Cette proposition ne sera pas publiée et quittera la liste principale.'"
        :important="confirmAction === 'approve'
                ? (publicationWarning || 'Vérifiez les gardes, les congés hebdomadaires, les repos post-garde et les cellules modifiées manuellement.')
                : confirmAction === 'regenerate'
                    ? `${manualCellCount} décision(s) manuelle(s) resteront prioritaires. Les écarts avec les règles resteront signalés pour contrôle.`
                    : 'Le rejet ne modifie aucun planning déjà publié.'"
        :confirm-label="confirmAction === 'approve'
                ? 'Publier le planning'
                : confirmAction === 'regenerate'
                    ? 'Régénérer le reste'
                    : 'Rejeter la suggestion'"
        @cancel="confirmAction = null"
        @confirm="resolveAction"
    />
  </div>
</template>

<script setup lang="ts">
import {
  computed,
  defineComponent,
  h,
  onMounted,
  ref,
} from 'vue'
import { useRoute, useRouter } from 'vue-router'
import {
  IconAlertTriangle,
  IconArrowLeft,
  IconEdit,
  IconRefresh,
  IconUsersGroup,
} from '@tabler/icons-vue'

import SessionTemplateService from '@/service/SessionTemplate'
import ScheduleSuggestionService from '@/service/ScheduleSuggestionService'

import PlanningConfirmDialog from '../components/PlanningConfirmDialog.vue'
import PlanningInfoPanel from '../components/PlanningInfoPanel.vue'
import PlanningPageHeader from '../components/PlanningPageHeader.vue'
import SuggestionBulkEditor from './SuggestionBulkEditor.vue'
import SuggestionFilters from './SuggestionFilters.vue'
import SuggestionIssueSummary from './SuggestionIssueSummary.vue'
import SuggestionPublicationBar from './SuggestionPublicationBar.vue'
import {
  ALLOCATION_LABELS,
  formatDate,
  responseData,
  responseError,
} from '../planningSuggestion.helpers'
import { reasonBusinessLabel } from '../teamWeeklyLeave.helpers'
import type {
  PlanningDayKey,
  PlanningTemplateMini,
  ScheduleSuggestion,
  ScheduleSuggestionItem,
  SuggestionReasonSource,
  GuardTeamSelectionMode,
  SuggestionGuardPool,
} from '../planningSuggestion.type'

const route = useRoute()
const router = useRouter()

const loading = ref(false)
const errorMessage = ref('')
const suggestion = ref<ScheduleSuggestion | null>(null)
const templates = ref<PlanningTemplateMini[]>([])
const activeTab = ref<'planning' | 'coverage' | 'issues'>('planning')
const bulkEditorOpen = ref(false)
const editorInitialItemGuid = ref<string | null>(null)
const editorInitialIso = ref<string | null>(null)
const confirmAction = ref<'approve' | 'reject' | 'regenerate' | null>(null)
const actionLoading = ref(false)
const employeeSearch = ref('')
const manualOnly = ref(false)
const guardOnly = ref(false)
const unassignedOnly = ref(false)

const dayKeys: PlanningDayKey[] = [
  'Sun',
  'Mon',
  'Tue',
  'Wed',
  'Thu',
  'Fri',
  'Sat',
]

const templateMap = computed(
    () => new Map(templates.value.map((template) => [template.guid, template])),
)

const historyReview = computed(
  () => suggestion.value?.diagnostics.historyReview ?? null,
)

const historyReviewMessage = computed(() => {
  const review = historyReview.value
  if (!review) return ''
  const ignored = review.summary?.ignoredAmbiguousRecords ?? 0
  const adjusted = review.summary?.adjustedAnomalyCount ?? 0
  const boundary = review.boundaryRelaxedForFeasibility
    ? ' Une continuité historique a aussi été relâchée pour ne pas rendre la suggestion impossible.'
    : ''
  return `${ignored} entrée(s) ambiguë(s) neutralisée(s) · ${adjusted} anomalie(s) ajustée(s) par le manager.${boundary}`
})

const temporaryExcludedNames = computed(() => {
  const names = generationScope.value?.temporaryExcludedEmployees
    ?.map((employee) => employee.name)
    .filter(Boolean) ?? []

  return names.length
    ? `Exclus pour cette suggestion : ${names.join(', ')}.`
    : 'Ces exclusions sont ponctuelles et ne modifient pas les profils employés.'
})

type GuardPoolView = SuggestionGuardPool & {
  selectionModeLabel: string
  employees: Array<{
    guid: string
    name: string
    employeeCode: string | null
    resolved: boolean
  }>
}

const GUARD_POOL_SELECTION_LABELS: Record<
    GuardTeamSelectionMode,
    string
> = {
  ROTATION_ORDER: 'Ordre de rotation',
  OPTIMIZED: 'Choix optimisé',
}

const guardPools = computed<GuardPoolView[]>(() => {
  const currentSuggestion = suggestion.value
  if (!currentSuggestion) return []

  const itemsByUserGuid = new Map(
      currentSuggestion.items.map(
          (item) => [item.user.guid, item] as const,
      ),
  )

  return [...(currentSuggestion.diagnostics.guardPools ?? [])]
      .filter((pool) => pool.mode === 'WEEKLY_POOL')
      .sort((a, b) => a.weekFrom.localeCompare(b.weekFrom))
      .map((pool): GuardPoolView => ({
        ...pool,
        selectionModeLabel:
            GUARD_POOL_SELECTION_LABELS[pool.selectionMode],
        employees: pool.employeeGuids.map((guid) => {
          const item = itemsByUserGuid.get(guid)

          return {
            guid,
            name: item?.user.name ?? 'Collaborateur introuvable',
            employeeCode: item?.user.employee_code ?? null,
            resolved: Boolean(item),
          }
        }),
      }))
})

const hardViolations = computed(() =>
    suggestion.value?.diagnostics.violations.filter(
        (violation) => violation.severity === 'HARD',
    ) ?? [],
)

const belowMinimumCoverage = computed(() =>
    suggestion.value?.diagnostics.coverage.filter(
        (coverage) => coverage.status === 'BELOW_MINIMUM',
    ) ?? [],
)

const warningViolations = computed(() =>
    suggestion.value?.diagnostics.violations.filter(
        (violation) => violation.severity === 'WARNING',
    ) ?? [],
)

const sortedCoverage = computed(() =>
    [...(suggestion.value?.diagnostics.coverage ?? [])].sort((left, right) => {
      const priority: Record<string, number> = {
        BELOW_MINIMUM: 0,
        ABOVE_MAXIMUM: 1,
        BELOW_TARGET: 2,
        COVERED: 3,
      }
      return (priority[left.status] ?? 9) - (priority[right.status] ?? 9)
        || left.date.localeCompare(right.date)
    }),
)

const sortedViolations = computed(() =>
    [...(suggestion.value?.diagnostics.violations ?? [])].sort((left, right) => {
      if (left.severity !== right.severity) return left.severity === 'HARD' ? -1 : 1
      return (left.date ?? '').localeCompare(right.date ?? '')
    }),
)

// Les diagnostics du moteur informent le manager mais ne prennent pas la décision
// à sa place. Les blocages techniques restent contrôlés par l'API de publication.
const canApprove = computed(() => Boolean(suggestion.value))

const publicationWarning = computed(() => {
  const parts: string[] = []

  if (hardViolations.value.length > 0) {
    parts.push(`${hardViolations.value.length} blocage(s) à examiner`)
  }

  if (belowMinimumCoverage.value.length > 0) {
    parts.push(`${belowMinimumCoverage.value.length} besoin(s) sous le minimum configuré`)
  }

  if (warningViolations.value.length > 0) {
    parts.push(`${warningViolations.value.length} avertissement(s)`)
  }

  return parts.length
    ? `${parts.join(' · ')}. La publication reste possible après confirmation du manager.`
    : ''
})

const calendarDays = computed(() => {
  if (!suggestion.value) return []

  const scheduleDates = suggestion.value.items.flatMap((item) =>
      Object.keys(item.schedule),
  )

  const maximumDate =
      scheduleDates.sort().at(-1) ?? suggestion.value.period_to

  const result: Array<{
    iso: string
    shortLabel: string
    dayMonth: string
    weekend: boolean
    outsidePeriod: boolean
  }> = []

  const current = new Date(
      `${suggestion.value.period_from}T12:00:00`,
  )
  const end = new Date(`${maximumDate}T12:00:00`)

  while (current <= end) {
    const iso = current.toISOString().slice(0, 10)

    result.push({
      iso,
      shortLabel: new Intl.DateTimeFormat('fr-FR', {
        weekday: 'short',
      })
          .format(current)
          .replace('.', ''),
      dayMonth: new Intl.DateTimeFormat('fr-FR', {
        day: '2-digit',
        month: '2-digit',
      }).format(current),
      weekend: [0, 6].includes(current.getDay()),
      outsidePeriod: iso > suggestion.value.period_to,
    })

    current.setDate(current.getDate() + 1)
  }

  return result
})

const manualCellCount = computed(() =>
    suggestion.value?.items.reduce(
        (count, item) => count + Object.keys(item.schedule).filter((iso) => isManual(item, iso)).length,
        0,
    ) ?? 0,
)

const guardCellCount = computed(() =>
    suggestion.value?.items.reduce(
        (count, item) => count + Object.keys(item.schedule).filter((iso) => isGuard(item, iso)).length,
        0,
    ) ?? 0,
)

const unassignedCellCount = computed(() =>
    suggestion.value?.items.reduce(
        (count, item) => count + Object.keys(item.schedule).filter((iso) => item.schedule[iso] === null).length,
        0,
    ) ?? 0,
)

const filteredItems = computed(() => {
  const query = employeeSearch.value.trim().toLocaleLowerCase('fr')
  return (suggestion.value?.items ?? []).filter((item) => {
    const matchesSearch = !query || [item.user.name, item.user.employee_code]
        .filter(Boolean)
        .some((value) => String(value).toLocaleLowerCase('fr').includes(query))
    const dates = Object.keys(item.schedule)
    const matchesManual = !manualOnly.value || dates.some((iso) => isManual(item, iso))
    const matchesGuard = !guardOnly.value || dates.some((iso) => isGuard(item, iso))
    const matchesUnassigned = !unassignedOnly.value || dates.some((iso) => item.schedule[iso] === null)
    return matchesSearch && matchesManual && matchesGuard && matchesUnassigned
  })
})

async function load(): Promise<void> {
  loading.value = true
  errorMessage.value = ''

  try {
    const [suggestionResponse, templateResponse] = await Promise.all([
      ScheduleSuggestionService.getByGuid(
          String(route.params.guid),
      ),
      SessionTemplateService.list({
        current: true,
        active: true,
        limit: 250,
      }),
    ])

    suggestion.value =
        responseData(suggestionResponse).suggestion ?? null

    templates.value =
        templateResponse?.data?.templates?.items ??
        templateResponse?.data?.session_templates?.items ??
        []
  } catch (error: any) {
    errorMessage.value = responseError(
        error,
        'Impossible de charger cette suggestion.',
    )
  } finally {
    loading.value = false
  }
}

function initials(name: string): string {
  return name
      .split(/\s+/)
      .slice(0, 2)
      .map((value) => value[0])
      .join('')
      .toUpperCase()
}

function reason(
    item: ScheduleSuggestionItem,
    iso: string,
) {
  return item.reasons?.[iso] ?? null
}

function isManual(
    item: ScheduleSuggestionItem,
    iso: string,
): boolean {
  return (
      reason(item, iso)?.factors?.some((factor) =>
          factor.toLowerCase().includes('manuel'),
      ) ?? false
  )
}

function source(
    item: ScheduleSuggestionItem,
    iso: string,
): SuggestionReasonSource | 'MANUAL' {
  if (isManual(item, iso)) return 'MANUAL'

  const explicitSource = reason(item, iso)?.source
  if (explicitSource) return explicitSource

  return item.schedule[iso] === null
      ? 'UNASSIGNED'
      : 'GENERATED'
}

function cellClasses(
    item: ScheduleSuggestionItem,
    iso: string,
): string {
  if (!(iso in item.schedule)) {
    return 'border-slate-100 bg-white text-slate-300'
  }

  const currentSource = source(item, iso)

  const classes: Record<
      SuggestionReasonSource | 'MANUAL',
      string
  > = {
    FIXED: 'border-blue-100 bg-blue-50 text-blue-800',
    GENERATED: isGuard(item, iso)
        ? 'border-violet-100 bg-violet-50 text-violet-800'
        : 'border-blue-100 bg-blue-50 text-blue-800',
    FILL_REMAINING:
        'border-blue-100 bg-blue-50 text-blue-800',
    GUARD_CONTINUATION:
        'border-violet-200 bg-violet-100 text-violet-900',
    POST_GUARD_REST:
        'border-amber-100 bg-amber-50 text-amber-800',
    WEEKLY_LEAVE:
        'border-rose-200 bg-rose-50 text-rose-800',
    TEMPLATE_REST:
        'border-slate-200 bg-slate-100 text-slate-600',
    UNASSIGNED:
        'border-dashed border-slate-200 bg-white text-slate-400',
    REST: 'border-slate-200 bg-slate-100 text-slate-500',
    MANUAL:
        'border-orange-200 bg-orange-50 text-orange-800',
  }

  return classes[currentSource]
}

function isGuard(
    item: ScheduleSuggestionItem,
    iso: string,
): boolean {
  const name = (reason(item, iso)?.templateName ?? '').toLowerCase()
  return name.includes('guard') || name.includes('garde')
}

type RestReasonSource = Extract<
    SuggestionReasonSource,
    | 'WEEKLY_LEAVE'
    | 'POST_GUARD_REST'
    | 'TEMPLATE_REST'
    | 'UNASSIGNED'
    | 'REST'
>

function isRestSource(value: SuggestionReasonSource | 'MANUAL',
): value is RestReasonSource {
  return ( value === 'WEEKLY_LEAVE' || value === 'POST_GUARD_REST' || value === 'TEMPLATE_REST' || value === 'UNASSIGNED' || value === 'REST')
}

function cellLabel(item: ScheduleSuggestionItem, iso: string): string {
  if (!(iso in item.schedule)) return '—'

  const currentSource = source(item, iso)
  const currentReason = reason(item, iso)

  if (isRestSource(currentSource)) {
    return reasonBusinessLabel(currentSource)
  }

  const templateGuid = item.schedule[iso]

  return currentReason?.templateName
      ?? (templateGuid ? templateMap.value.get(templateGuid)?.name : undefined)
      ?? 'Service'
}

function cellTime(
    item: ScheduleSuggestionItem,
    iso: string,
): string {
  if (!(iso in item.schedule)) return ''

  const templateGuid = item.schedule[iso]
  if (!templateGuid) return '—'

  const template = templateMap.value.get(templateGuid)
  const day = dayKeys[new Date(`${iso}T12:00:00`).getDay()]
  const blocks = template?.definition?.[day]

  return Array.isArray(blocks) && blocks.length
      ? `${blocks[0].work[0]}–${blocks[0].work[1]}`
      : 'Horaire'
}

function resetPlanningFilters(): void {
  employeeSearch.value = ''
  manualOnly.value = false
  guardOnly.value = false
  unassignedOnly.value = false
}

function activateManualFilter(): void {
  activeTab.value = 'planning'
  manualOnly.value = true
  guardOnly.value = false
  unassignedOnly.value = false
}

function activateUnassignedFilter(): void {
  activeTab.value = 'planning'
  unassignedOnly.value = true
  manualOnly.value = false
  guardOnly.value = false
}

function openBulkEditor(): void {
  editorInitialItemGuid.value = null
  editorInitialIso.value = null
  bulkEditorOpen.value = true
}

function openCell(
    item: ScheduleSuggestionItem,
    iso: string,
): void {
  if (!(iso in item.schedule)) return

  // Un clic cellule ouvre le même éditeur que « Modifier en masse »,
  // prérempli sur 1 collaborateur × 1 jour. Le manager peut ensuite élargir
  // librement à plusieurs dates ou à une période.
  editorInitialItemGuid.value = item.guid
  editorInitialIso.value = iso
  bulkEditorOpen.value = true
}

function closePlanningEditor(): void {
  bulkEditorOpen.value = false
  editorInitialItemGuid.value = null
  editorInitialIso.value = null
}

async function onBulkSaved(): Promise<void> {
  closePlanningEditor()
  await load()
}

async function resolveAction(): Promise<void> {
  if (!suggestion.value || !confirmAction.value) return

  const action = confirmAction.value
  actionLoading.value = true

  try {
    const response =
        action === 'approve'
            ? await ScheduleSuggestionService.approve(
                suggestion.value.guid,
            )
            : action === 'regenerate'
                ? await ScheduleSuggestionService.regenerate(
                    suggestion.value.guid,
                )
                : await ScheduleSuggestionService.reject(
                    suggestion.value.guid,
                )

    if (!response?.success) throw response

    confirmAction.value = null

    if (action === 'regenerate') {
      await load()
      return
    }

    await router.push({
      name:
          action === 'approve'
              ? 'schedule-assignment'
              : 'planning-suggestion-list',
    })
  } catch (error: any) {
    if (action === 'regenerate') {
      const details =
          error?.details ??
          error?.error?.details ??
          error?.data?.details ??
          error?.data?.error?.details ??
          error?.response?.data?.error?.details
      const firstBlocker = Array.isArray(details?.blockers)
          ? details.blockers[0]
          : null
      const suggestedAction = Array.isArray(firstBlocker?.suggested_actions)
          ? firstBlocker.suggested_actions[0]
          : null

      errorMessage.value = firstBlocker?.message
          ? `${firstBlocker.message}${suggestedAction ? ` — ${suggestedAction}` : ''}`
          : responseError(
              error,
              'La régénération n’a pas pu être exécutée.',
          )
    } else {
      errorMessage.value = responseError(
          error,
          'Cette action n’a pas pu être exécutée.',
      )
    }
    confirmAction.value = null
  } finally {
    actionLoading.value = false
  }
}

function coverageLabel(status: string): string {
  return {
    COVERED: 'Couvert',
    BELOW_TARGET: 'Sous la cible',
    BELOW_MINIMUM: 'Minimum non atteint',
    ABOVE_MAXIMUM: 'Maximum dépassé',
  }[status] ?? status
}

function coverageClass(status: string): string {
  return {
    COVERED: 'bg-emerald-50 text-emerald-700',
    BELOW_TARGET: 'bg-amber-50 text-amber-700',
    BELOW_MINIMUM: 'bg-red-50 text-red-700',
    ABOVE_MAXIMUM: 'bg-orange-50 text-orange-700',
  }[status] ?? 'bg-slate-100 text-slate-600'
}

function severityLabel(severity: 'HARD' | 'WARNING'): string {
  return severity === 'HARD' ? 'Écart fort' : 'Avertissement'
}

const Score = defineComponent({
  props: {
    label: String,
    description: String,
    value: Number,
  },
  setup(props) {
    return () =>
        h('div', { class: 'bg-white p-5' }, [
          h(
              'p',
              {
                class: 'text-xs font-bold uppercase tracking-[0.12em] text-slate-400',
              },
              props.label,
          ),
          h(
              'p',
              {
                class: 'mt-1 text-2xl font-bold text-slate-900',
              },
              `${props.value ?? 0}%`,
          ),
          props.description
              ? h(
                  'p',
                  { class: 'mt-1 text-xs leading-4 text-slate-400' },
                  props.description,
                )
              : null,
        ])
  },
})

const Info = defineComponent({
  props: {
    label: String,
    value: String,
  },
  setup(props) {
    return () =>
        h('div', { class: 'bg-white p-5' }, [
          h(
              'p',
              {
                class: 'text-xs font-bold uppercase tracking-[0.12em] text-slate-400',
              },
              props.label,
          ),
          h(
              'p',
              {
                class: 'mt-1 text-lg font-bold text-slate-900',
              },
              props.value,
          ),
        ])
  },
})

const Legend = defineComponent({
  props: {
    label: String,
    tone: String,
  },
  setup(props) {
    const colors: Record<string, string> = {
      indigo: 'bg-blue-500',
      blue: 'bg-blue-500',
      violet: 'bg-violet-500',
      rose: 'bg-rose-500',
      amber: 'bg-amber-500',
      slate: 'bg-slate-400',
      empty: 'border border-dashed border-slate-400 bg-white',
    }

    return () =>
        h(
            'span',
            {
              class: 'inline-flex items-center gap-2 text-xs font-semibold text-slate-500',
            },
            [
              h('span', {
                class: `h-2 w-2 rounded-full ${
                    colors[props.tone ?? 'slate']
                }`,
              }),
              props.label,
            ],
        )
  },
})

onMounted(load)
</script>

<style scoped>
.primary-button,
.secondary-button,
.danger-button {
  display: inline-flex;
  align-items: center;
  gap: 0.45rem;
  border-radius: 0.75rem;
  padding: 0.65rem 0.9rem;
  font-size: 0.75rem;
  font-weight: 700;
}

.primary-button {
  background: #1d4ed8;
  color: #fff;
}

.secondary-button {
  border: 1px solid #e2e8f0;
  background: #fff;
  color: #475569;
}

.danger-button {
  border: 1px solid #fecaca;
  background: #fff;
  color: #dc2626;
}

.tab-button {
  border-radius: 0.55rem;
  padding: 0.5rem 0.75rem;
  font-size: 0.75rem;
  font-weight: 700;
  color: #64748b;
}

.tab-button.active {
  background: #0f172a;
  color: #fff;
}

.cell-card {
  position: relative;
  width: 100%;
  min-height: 48px;
  border-width: 1px;
  border-radius: 0.7rem;
  padding: 0.45rem 0.4rem;
  text-align: center;
  transition: 0.14s;
}

.cell-card:not(:disabled):hover {
  transform: translateY(-1px);
  box-shadow: 0 4px 10px rgb(15 23 42 / 0.08);
}

.cell-card:disabled {
  cursor: default;
}
</style>
