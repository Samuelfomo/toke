# Intégration du paquet cumulatif dans le projet tenant

## Destination

Extraire l'archive à la racine du projet. Tous les fichiers applicatifs se
placent sous :

```text
src/tenant/modules/attendance-statistics/
```

Le paquet ne contient aucun fichier pour `master`, `middle` ou `realtime`.

## Arborescence livrée

```text
src/tenant/modules/attendance-statistics/
├── README.md
├── application/
│   ├── attendance-activity.ts
│   ├── attendance-day-service.types.ts
│   ├── attendance-day.service.ts
│   ├── attendance-overview.types.ts
│   ├── attendance-overview.ts
│   └── business-calendar.ts
├── domain/
│   ├── attendance-day.types.ts
│   └── attendance-day.ts
├── infrastructure/
│   └── legacy/
│       ├── legacy-attendance-schedule.repository.ts
│       ├── legacy-attendance-session.repository.ts
│       ├── legacy-business-time.ts
│       ├── tenant-attendance-day.factory.ts
│       ├── toke-attendance-schedule.datasource.ts
│       └── toke-attendance-session.datasource.ts
├── docs/
├── examples/
└── tests placés à côté des sources concernées
```

## Ce qui est déjà raccordé

- `WorkSessions` fournit les sessions et leurs durées consolidées.
- `TimeEntries` permet de vérifier les paires de pauses lorsque nécessaire.
- `ScheduleAssignments` fournit les snapshots des horaires directs.
- `RotationAssignments`, `RotationGroups` et leurs slots fournissent la
  rotation courante.
- `Groups` fournit l'appartenance actuelle connue.

Les imports des deux data sources remontent vers les classes existantes de
`src/tenant/class` avec le suffixe `.js`, conformément au style actuel du
projet TypeScript/ESM.

## Ce que l'extraction ne modifie pas

- `src/tenant/routes/attendance.stat.route.ts` ;
- `src/tenant/app.ts` ;
- les classes et modèles existants ;
- le schéma de base de données.

Le paquet peut donc être copié sans activer un nouvel endpoint. Le futur lot
ajoutera l'orchestration HTTP après validation de l'historique et du périmètre
d'équipe.

## Vérification après copie

Exécuter les scripts habituels du projet tenant, en particulier son build
TypeScript complet. Le `tsconfig.json` inclus sert seulement à valider le noyau
autonome et exclut les deux adaptateurs `toke-*`, qui dépendent des classes du
projet hôte.

## Données critiques encore utiles

Pour remplacer les journées historiques indéterminées par une résolution
fiable, fournir uniquement les classes, modèles et structures DB suivantes :

1. `RotationAssignmentLog` ;
2. `RotationGroupTemplateLog` ;
3. `ScheduleAssignmentsLog`.

Une date de sortie d'un membre de groupe, si elle existe dans une autre table
ou un journal, est également nécessaire pour reconstruire l'équipe à une date
passée. Son absence ne bloque pas l'intégration : les cas non prouvés restent
simplement exclus des taux.
