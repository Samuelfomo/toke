# Manifeste du lot 3

Cette archive est cumulative : elle contient les lots 1, 2 et 3.

## Lot 1

- contrat `AttendanceDay` ;
- classification pure ;
- tests des statuts et signaux.

## Lot 2

- contrat JSON de l'overview ;
- agrégation des taux, activités et qualités de données ;
- documentation et exemple de réponse.

## Lot 3

- calendrier métier et gestion des gardes ;
- regroupement des sessions et contrôle des durées/pauses ;
- `AttendanceDayService` ;
- repositories de sessions et de plannings ;
- data sources vers les classes du tenant ;
- factory de composition destinée au futur contrôleur ;
- tests des repositories et du service.

## Validation réalisée

- 53 tests métier réussis ;
- compilation TypeScript stricte du noyau réussie ;
- adaptateurs tenant vérifiés contre les signatures des classes fournies ;
- aucun changement apporté à la route existante.
