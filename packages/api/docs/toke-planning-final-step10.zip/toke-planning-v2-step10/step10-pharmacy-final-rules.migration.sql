-- Step 10 — Pharmacy final rules

DO $$
BEGIN
  CREATE TYPE enum_xa_employee_planning_profile_fixed_rest_day_mode
    AS ENUM ('TEMPLATE', 'ROTATING');
EXCEPTION
  WHEN duplicate_object THEN NULL;
END
$$;

ALTER TABLE public.xa_planning_suggestion_config
  ADD COLUMN IF NOT EXISTS post_guard_rest_days INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS max_resting_employees_per_day INTEGER NULL;

ALTER TABLE public.xa_planning_suggestion_config
  DROP CONSTRAINT IF EXISTS check_planning_suggestion_post_guard_rest_days,
  DROP CONSTRAINT IF EXISTS check_planning_suggestion_daily_rest_capacity;

ALTER TABLE public.xa_planning_suggestion_config
  ADD CONSTRAINT check_planning_suggestion_post_guard_rest_days
    CHECK (post_guard_rest_days BETWEEN 0 AND 31),
  ADD CONSTRAINT check_planning_suggestion_daily_rest_capacity
    CHECK (
      max_resting_employees_per_day IS NULL
      OR max_resting_employees_per_day >= 1
    );

ALTER TABLE public.xa_employee_planning_profile
  ADD COLUMN IF NOT EXISTS fixed_rest_day_mode
    enum_xa_employee_planning_profile_fixed_rest_day_mode
    NOT NULL DEFAULT 'TEMPLATE';

ALTER TABLE public.xa_employee_planning_profile
  DROP CONSTRAINT IF EXISTS check_employee_fixed_rest_day_mode;

ALTER TABLE public.xa_employee_planning_profile
  ADD CONSTRAINT check_employee_fixed_rest_day_mode
    CHECK (
      planning_mode = 'FIXED'
      OR fixed_rest_day_mode = 'TEMPLATE'
    );

ALTER TABLE public.xa_planning_suggestion_requirement
  ADD COLUMN IF NOT EXISTS credited_minutes INTEGER NULL;

ALTER TABLE public.xa_planning_suggestion_requirement
  DROP CONSTRAINT IF EXISTS check_planning_requirement_credited_minutes;

ALTER TABLE public.xa_planning_suggestion_requirement
  ADD CONSTRAINT check_planning_requirement_credited_minutes
    CHECK (
      credited_minutes IS NULL
      OR credited_minutes BETWEEN 1 AND 10080
    );
