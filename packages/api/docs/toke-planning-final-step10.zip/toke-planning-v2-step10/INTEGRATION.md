# Step 10 — Finalisation pharmacie

## Règles ajoutées

### `post_guard_rest_days`

Nombre de jours calendaires entièrement libres après la journée de continuation.

- `0` : garde lundi, continuation mardi, retour possible mercredi ;
- `1` : garde lundi, continuation mardi, repos mercredi, retour jeudi ;
- `2` : mercredi et jeudi en repos, retour vendredi.

La continuation reste toujours une activité et bloque les autres services de sa date.

### `fixed_rest_day_mode`

- `TEMPLATE` : le template fixe décide des jours travaillés et de repos ;
- `ROTATING` : l’horaire reste fixe mais CP-SAT choisit les jours de repos.

### `max_resting_employees_per_day`

Capacité optionnelle. Laisser `null` tant que la pharmacie n’a pas confirmé une limite
quotidienne exacte. Une valeur trop faible peut rendre le planning impossible.

### `credited_minutes`

Durée métier créditée pour un besoin. Pour une garde 16h–08h : `960` minutes.
La durée est répartie entre le début et la continuation, y compris lorsqu’ils tombent
dans deux semaines différentes.

## Configuration Pharmacie du Plateau

```json
{
  "min_rest_days_per_week": 1,
  "max_consecutive_work_days": 6,
  "max_consecutive_guards": 1,
  "rest_after_guard_required": true,
  "post_guard_rest_days": 1,
  "max_resting_employees_per_day": null,
  "solver_type": "ORTOOLS",
  "solver_timeout_seconds": 30,
  "fallback_to_greedy": false
}
```

## Important

Le frontend doit exposer ces champs comme des règles du client, pas comme des normes
imposées par Toké.

## Frontière de période

Si une garde commence à la fin de la suggestion, l’item contient également :

- la continuation hors période ;
- les jours `POST_GUARD_REST` hors période.

Le service d’approbation les publie comme des assignments individuels afin que la
récupération reste protégée après la date officielle de fin du planning.
