# Ordre d’intégration Step 10

1. Exécuter `step10-pharmacy-final-rules.migration.sql` sur chaque base tenant.
2. Remplacer les fichiers de configuration PlanningSuggestionConfig.
3. Remplacer les fichiers EmployeePlanningProfile.
4. Remplacer les fichiers PlanningSuggestionRequirement.
5. Remplacer `suggestion.engine.ts`.
6. Remplacer `planning.solver.ts` et le service de génération.
7. Remplacer `schedule.suggestion.approval.service.ts` pour publier continuation et repos post-garde hors période.
8. Remplacer `planning-ortools/app/schemas.py`, `solver.py`, `main.py` et requirements.
9. Réinstaller les dépendances Python : `pip install -r requirements.txt`.
10. Compiler les packages partagés puis l’API.
11. Redémarrer OR-Tools et api-tenant.
12. Appliquer la configuration Pharmacie du Plateau.
13. Depuis `packages/planning-ortools`, exécuter `python test_pharmacy_scenario.py`, puis générer le scénario du 3 au 16 août 2026 et contrôler garde → continuation → repos → retour.
