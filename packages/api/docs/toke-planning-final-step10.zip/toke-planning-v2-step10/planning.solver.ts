import {
  EngineConfig,
  EngineDiagnostics,
  EngineResult,
  HistoricalAssignment,
  PlanningEmployeeInput,
  PlanningRequirementInput,
} from './suggestion.engine.js';

export type PlanningSolverType =
  | 'GREEDY'
  | 'ORTOOLS';

export interface PlanningSolverInput {
  employees: PlanningEmployeeInput[];
  requirements: PlanningRequirementInput[];
  historicalAssignments: HistoricalAssignment[];
  periodFrom: string;
  periodTo: string;
  config: EngineConfig;
  solverTimeoutSeconds?: number;
}

export interface PlanningSolverExecutionMetadata {
  requestedSolver: PlanningSolverType;
  usedSolver: PlanningSolverType;
  fallbackUsed: boolean;
  durationMs: number;
  solverVersion: string;
  warning?: string;
}

export interface PlanningSolverExecutionResult {
  result: EngineResult;
  metadata: PlanningSolverExecutionMetadata;
}

export interface PlanningSolver {
  readonly type: PlanningSolverType;
  readonly version: string;

  solve(
    input: PlanningSolverInput,
  ): Promise<EngineResult>;
}

export class PlanningSolverTechnicalError extends Error {
  constructor(
    message: string,
    public readonly code:
      | 'PLANNING_SOLVER_UNAVAILABLE'
      | 'PLANNING_SOLVER_TIMEOUT'
      | 'PLANNING_SOLVER_PROTOCOL_ERROR',
    public readonly details?: unknown,
  ) {
    super(message);
    this.name = 'PlanningSolverTechnicalError';
  }
}

export function withSolverDiagnostics(
  diagnostics: EngineDiagnostics,
  metadata: PlanningSolverExecutionMetadata,
): EngineDiagnostics & {
  solver: PlanningSolverExecutionMetadata;
} {
  return {
    ...diagnostics,
    solver: metadata,
  };
}
