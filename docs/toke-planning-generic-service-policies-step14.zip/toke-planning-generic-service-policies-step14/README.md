# Step 14 — Politiques de planning génériques par population et service

## Objectif

Ce lot transforme le module de suggestion en moteur déclaratif multi-tenant.
Aucune branche ne dépend d’un nom de client, d’un GUID d’employé ou d’un nombre
dérivé de la Pharmacie du Plateau.

Une configuration peut désormais exprimer :

- qui peut couvrir chaque besoin : `FIXED`, `ROTATING`, membre ou non-membre du pool ;
- qui reçoit un repos hebdomadaire ;
- un nombre minimum ou exact de repos par employé éligible ;
- les jours autorisés et le maximum de repos simultanés ;
- le service auquel la politique s’applique : tout service, type, template ou besoin ;
- l’obligation de travailler sur ce périmètre tous les autres jours ;
- un pool de garde hebdomadaire avec accès `GUARD_ONLY` ;
- l’équilibrage souple ou strict des appartenances au pool sur la période.

Le besoin Plateau devient une simple fixture dans `examples/`.

## Modèle générique

### Sélecteur de population

```json
{
  "planning_modes": ["ROTATING"],
  "guard_pool_relation": "NON_MEMBER"
}
```

Relations disponibles : `ANY`, `MEMBER`, `NON_MEMBER`.

### Périmètre de service

```json
{
  "mode": "SERVICE_TYPE",
  "service_types": ["STANDARD"],
  "template_guids": [],
  "requirement_guids": [],
  "exclusive": true
}
```

Modes disponibles : `ANY`, `SERVICE_TYPE`, `TEMPLATE`, `REQUIREMENT`.

### Éligibilité d’un besoin

```json
{
  "eligibility_policy": {
    "planning_modes": ["ROTATING"],
    "guard_pool_relation": "MEMBER"
  }
}
```

Cette propriété est configurée dans l’interface de chaque besoin de couverture.

Deux besoins peuvent désormais utiliser le même jour et le même template lorsqu’ils
ciblent des populations différentes. Par exemple, un besoin `FIXED + ANY` et un
besoin `ROTATING + NON_MEMBER` restent deux quotas indépendants. La base bloque
uniquement un doublon portant sur le même slot **et le même sélecteur de population**.

## Comportement Plateau obtenu sans code spécifique

Pour chaque semaine complète :

1. OR-Tools choisit 6 employés parmi les 10 profils `ROTATING` ;
2. les besoins de garde `MEMBER` utilisent uniquement ce pool ;
3. les besoins standards `NON_MEMBER` utilisent automatiquement les 4 autres ;
4. chaque non-membre reçoit exactement 1 repos entre jeudi et dimanche ;
5. un maximum de 1 repos est autorisé par jour ;
6. chaque non-membre travaille sur le service ciblé pendant les 6 autres jours ;
7. les membres du pool ne reçoivent pas ce repos et restent `GUARD_ONLY` ;
8. l’appartenance au pool est équilibrée sur la période mensuelle.

Le chiffre 4 n’existe pas dans le solveur : il résulte de `10 - 6`.

## Compatibilité

Les anciens tenants conservent leur comportement grâce aux valeurs par défaut :

- pool `DAILY_FLEXIBLE` ;
- portée de repos `ANY` ;
- besoins accessibles aux profils `FIXED` et `ROTATING` ;
- relation au pool `ANY` ;
- équilibrage de pool `NONE` ;
- accès des membres à `ANY_SERVICE`.

Les modes historiques `NONE`, `PER_EMPLOYEE` et `TEAM_ROTATION` restent pris en charge.

## Fichiers backend

À remplacer :

- `PlanningSuggestionConfigModel.ts`
- `PlanningSuggestionConfig.ts`
- `planning.suggestion.config.db.ts`
- `planning.suggestion.config.ts`
- `planning.suggestion.config.route.ts`
- `PlanningSuggestionRequirementModel.ts`
- `PlanningSuggestionRequirement.ts`
- `planning.suggestion.requirement.db.ts`
- `planning.suggestion.requirement.ts`
- `planning.suggestion.requirement.route.ts`
- `schedule.suggestion.generation.service.ts`
- `suggestion.engine.ts`
- `solver/planning.solver.ts`
- `solver/planning.solver.factory.ts`
- `solver/ortools.planning.solver.ts`
- `planning-ortools/app/schemas.py`
- `planning-ortools/app/solver.py`
- `planning-ortools/app/main.py`

À ajouter :

- `step14-service-scoped-policies.migration.sql`
- `planning-ortools/tests/test_policy_schema_v2.py`
- `planning-ortools/tests/test_service_scoped_weekly_leave.py`

Le lot conserve aussi les fichiers Step 13 nécessaires au pool hebdomadaire.

## Fichiers frontend

À remplacer :

- `planningSuggestion.type.ts`
- `configuration/PlanningConfigForm.vue`
- `requirements/PlanningRequirementForm.vue`
- `teamWeeklyLeave.helpers.ts`

L’interface ne contient plus `PLATEAU_WEEKLY_LEAVE_DAYS` ni de bouton spécifique à un tenant.

## Migration

Exécuter après la migration Step 13 :

```bash
psql -v ON_ERROR_STOP=1 -d <tenant_db> \
  -f backend/step14-service-scoped-policies.migration.sql
```

Puis reconstruire et redémarrer :

```bash
npm run build
pm2 restart api-backend
pm2 restart api-tenant
pm2 restart toke-planning-ortools
```

## Tests serveur

```bash
cd /opt/toke/packages/planning-ortools
source .venv/bin/activate

python tests/test_policy_schema_v2.py
python tests/test_weekly_guard_pool.py
python tests/test_service_scoped_weekly_leave.py
```

Le dernier test couvre quatre semaines avec 3 profils fixes, 10 rotatifs, un
pool de 6, 3 gardes par jour et 1 repos exact pour chacun des 4 non-membres.

## Configuration Plateau depuis l’interface

### Règles moteur

- Repos : `Politique avancée ciblée` ;
- population : `ROTATING` + `NON_MEMBER` ;
- quantité : `1`, mode `EXACT` ;
- jours : jeudi à dimanche ;
- maximum par jour : `1` ;
- travail les autres jours : activé ;
- périmètre : template du service du matin, exclusif ;
- pool : `WEEKLY_POOL`, taille `6`, sélection `OPTIMIZED` ;
- accès membre : `GUARD_ONLY` ;
- équilibrage : `STRICT`, écart `1`, semaines consécutives `2` ;
- OR-Tools, fallback désactivé.

### Besoins

- chaque garde : `ROTATING` + `MEMBER`, `EXACT 3` ;
- service du matin rotatif : `ROTATING` + `NON_MEMBER` ;
- lundi à mercredi : `EXACT 4` ;
- jeudi à dimanche : `EXACT 3`.

Les trois profils fixes restent pilotés par leurs propres templates et ne sont
pas comptés dans ces besoins rotatifs.
