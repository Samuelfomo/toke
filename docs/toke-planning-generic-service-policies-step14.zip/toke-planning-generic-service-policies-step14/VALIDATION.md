# Validation du paquet Step 14

## Vérifications exécutées dans l'environnement de génération

- compilation syntaxique de tous les fichiers Python avec `py_compile` ;
- validation Pydantic du schéma de politique v2 ;
- test du cycle déterministe `rotation_order` ;
- test de capacité du pool de 6 pour 21 débuts de garde avec un écart de 2 jours ;
- rejet vérifié du même pool lorsque l'écart passe à 3 jours ;
- transpilation de tous les fichiers TypeScript et des blocs `<script setup lang="ts">` ;
- vérification TypeScript stricte des types frontend autonomes ;
- validation JSON des exemples ;
- contrôle de l'absence de branche tenant/client dans le code principal.

## Test CP-SAT à exécuter sur le serveur Toké

L'environnement de génération utilise Python 3.13 et ne dispose pas d'une roue
OR-Tools compatible. Le scénario CP-SAT complet est fourni mais n'a pas été
exécuté ici.

Sur le serveur où la dépendance `ortools==9.14.6206` est installée :

```bash
cd /opt/toke/packages/planning-ortools
source .venv/bin/activate
python tests/test_service_scoped_weekly_leave.py
```

Ce test vérifie quatre semaines complètes avec :

- 3 profils fixes et 10 profils rotatifs ;
- un pool hebdomadaire de 6 ;
- 3 gardes par jour ;
- 4 rotatifs hors pool ;
- exactement un repos par non-membre entre jeudi et dimanche ;
- exactement 6 services standards par non-membre ;
- aucun repos métier pour les membres du pool ;
- un équilibrage mensuel de l'appartenance au pool.
